"""ApexPvP launcher window (customtkinter)."""
from __future__ import annotations

import math
import os
import queue
import subprocess
import sys
import threading
import time
import webbrowser
from pathlib import Path
import tkinter as tk
from tkinter import filedialog

import customtkinter as ctk
from PIL import Image, ImageChops, ImageDraw, ImageEnhance, ImageFilter, ImageTk

from . import __version__, auth, config, installer, pack, scenery
from .music import MusicPlayer
from .overlay import NowPlayingOverlay
from .paths import DEFAULT_MUSIC_DIR, GAME_DIR, LOG_DIR, ensure_dirs

BG = "#120c1e"
GLASS = "#1b1329"        # big page cards
BORDER = "#4a3a63"
CARD = "#271c3d"         # inner cards
CARD_HI = "#35284f"
ACCENT = "#ff8a45"
ACCENT_HI = "#ffa468"
TEXT = "#f6f0ff"
MUTED = "#b3a5cc"
GOOD = "#57e3a1"
SHADOW = "#22103a"
FONT = "Roboto"          # shipped with customtkinter

DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September",
          "October", "November", "December"]
DOCK = [("Play", "play"), ("Mods", "mods"), ("Pack", "pack"), ("Music", "music"),
        ("Settings", "settings"), ("Exit", "exit")]


def open_path(p: Path) -> None:
    p = Path(p)
    p.mkdir(parents=True, exist_ok=True)
    if os.name == "nt":
        os.startfile(str(p))                       # type: ignore[attr-defined]
    elif sys.platform == "darwin":
        subprocess.Popen(["open", str(p)])
    else:
        subprocess.Popen(["xdg-open", str(p)])


# ------------------------------------------------------------------ glass rendering
def _rounded_mask(w: int, h: int, radius: int, s: int = 3) -> Image.Image:
    m = Image.new("L", (w * s, h * s), 0)
    ImageDraw.Draw(m).rounded_rectangle([0, 0, w * s - 1, h * s - 1], radius * s, fill=255)
    return m.resize((w, h), Image.LANCZOS)


def glass(bg: Image.Image, box, radius: int, tint=(255, 255, 255), tint_a=0.16, dark=0.85,
          border=0.45, glyph=None) -> Image.Image:
    """Frosted-glass tile: blurred + tinted crop of the wallpaper with a soft border and optional glyph."""
    x0, y0, x1, y1 = [int(v) for v in box]
    w, h = x1 - x0, y1 - y0
    crop = bg.crop((x0, y0, x1, y1)).convert("RGB").filter(ImageFilter.GaussianBlur(9))
    crop = ImageEnhance.Brightness(crop).enhance(dark)
    crop = Image.blend(crop, Image.new("RGB", (w, h), tint), tint_a)
    mask = _rounded_mask(w, h, radius)
    inner = Image.new("L", (w, h), 0)
    inner.paste(_rounded_mask(w - 4, h - 4, max(1, radius - 2)), (2, 2))
    ring = ImageChops.subtract(mask, inner).point(lambda v: int(v * border))
    crop = Image.composite(Image.new("RGB", (w, h), (255, 255, 255)), crop, ring)
    out = crop.convert("RGBA")
    if glyph:
        S = 3
        layer = Image.new("RGBA", (w * S, h * S), (0, 0, 0, 0))
        glyph(ImageDraw.Draw(layer), w * S, h * S)
        out.alpha_composite(layer.resize((w, h), Image.LANCZOS))
    out.putalpha(mask)
    return out


def _icon(kind: str):
    white = (255, 255, 255, 245)

    def draw(d: ImageDraw.ImageDraw, W: int, H: int) -> None:
        s = min(W, H)
        ox, oy = (W - s) / 2, (H - s) / 2
        P = lambda x, y: (ox + x * s, oy + y * s)
        lw = max(2, int(s * 0.055))
        if kind == "play":
            d.polygon([P(.39, .28), P(.39, .72), P(.75, .50)], fill=white)
        elif kind == "mods":
            hexa = [P(.5, .24), P(.74, .37), P(.74, .63), P(.5, .76), P(.26, .63), P(.26, .37)]
            d.line(hexa + [hexa[0]], fill=white, width=lw, joint="curve")
            d.line([P(.26, .37), P(.5, .50), P(.74, .37)], fill=white, width=lw, joint="curve")
            d.line([P(.5, .50), P(.5, .76)], fill=white, width=lw)
        elif kind == "pack":
            d.line([P(.34, .66), P(.72, .28)], fill=white, width=lw + 2)
            d.line([P(.28, .52), P(.48, .72)], fill=white, width=lw)
            d.line([P(.28, .72), P(.35, .65)], fill=white, width=lw)
        elif kind == "music":
            r = .085 * s
            cx, cy = P(.40, .68)
            d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=white)
            d.line([P(.475, .68), P(.475, .30)], fill=white, width=lw)
            d.polygon([P(.475, .30), P(.70, .38), P(.70, .48), P(.475, .40)], fill=white)
        elif kind == "settings":
            cx, cy = P(.5, .5)
            for k in range(8):
                a = k * math.pi / 4
                d.line([(cx + math.cos(a) * .19 * s, cy + math.sin(a) * .19 * s),
                        (cx + math.cos(a) * .29 * s, cy + math.sin(a) * .29 * s)], fill=white, width=lw + 3)
            r = .19 * s
            d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=white, width=lw + 1)
            r = .07 * s
            d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=white)
        elif kind == "exit":
            d.line([P(.34, .34), P(.66, .66)], fill=white, width=lw + 1)
            d.line([P(.66, .34), P(.34, .66)], fill=white, width=lw + 1)
    return draw


class LoginDialog(ctk.CTkToplevel):
    """Microsoft sign-in window: shows a code, waits for approval, stores the account."""

    def __init__(self, app: "App"):
        super().__init__(app)
        self.app = app
        self.cancel = threading.Event()
        self.title("Sign in with Microsoft")
        self.geometry("560x520")
        self.resizable(False, False)
        self.configure(fg_color=GLASS)
        self.transient(app)
        self.protocol("WM_DELETE_WINDOW", self._close)
        self.body = ctk.CTkFrame(self, fg_color="transparent")
        self.body.pack(fill="both", expand=True, padx=28, pady=24)
        self.after(60, self._center)
        self.after(150, self._grab)
        if self._client_id():
            self._start()
        else:
            self._show_setup()

    # -- helpers
    def _center(self) -> None:
        try:
            a = self.app
            self.geometry(f"+{a.winfo_rootx() + (a.winfo_width() - 560) // 2}+{a.winfo_rooty() + (a.winfo_height() - 520) // 2}")
        except Exception:
            pass

    def _grab(self) -> None:
        try:
            self.grab_set()
            self.focus_force()
        except Exception:
            pass

    def _client_id(self) -> str:
        return (self.app.cfg["ms_client_id"] or auth.BUNDLED_CLIENT_ID).strip()

    def _clear(self) -> None:
        for w in self.body.winfo_children():
            w.destroy()

    def _alive(self) -> bool:
        try:
            return bool(self.winfo_exists())
        except Exception:
            return False

    def _close(self) -> None:
        self.cancel.set()
        try:
            self.grab_release()
        except Exception:
            pass
        self.destroy()

    def _label(self, text, size=14, color=TEXT, bold=False, pady=(0, 8), wrap=500):
        lab = ctk.CTkLabel(self.body, text=text, text_color=color, anchor="w", justify="left", wraplength=wrap,
                           font=ctk.CTkFont(family=FONT, size=size, weight="bold" if bold else "normal"))
        lab.pack(fill="x", pady=pady)
        return lab

    def _btn(self, text, cmd, accent=False, **kw):
        b = (self.app._accent_btn if accent else self.app._ghost_btn)(self.body, text, cmd, height=40, **kw)
        b.pack(fill="x", pady=4)
        return b

    # -- screens
    def _show_setup(self, note: str = "") -> None:
        self._clear()
        self._label("One-time setup", 24, bold=True, pady=(0, 4))
        self._label("Microsoft only lets a launcher sign players in when the launcher has its own free app "
                    "registration that Mojang approved. Nobody can do that for you, so do it once:", 13, MUTED)
        self._label("1. Azure portal > App registrations > New registration. Name: ApexPvP. "
                    "Account type: personal Microsoft accounts only. Leave the redirect URI empty.\n"
                    "2. Authentication > turn on 'Allow public client flows' > Save.\n"
                    "3. Copy the Application (client) ID and paste it below.\n"
                    "4. Send it to Mojang with the approval form (usually takes a few days).", 13, TEXT, pady=(0, 10))
        row = ctk.CTkFrame(self.body, fg_color="transparent")
        row.pack(fill="x", pady=(0, 6))
        self._btn_row(row)
        self.entry = ctk.CTkEntry(self.body, placeholder_text="Application (client) ID", placeholder_text_color=MUTED, height=40)
        self.entry.pack(fill="x", pady=(4, 4))
        if note:
            self._label(note, 13, ACCENT, pady=(0, 4))
        self._btn("Save and sign in", self._save_and_start, accent=True)

    def _btn_row(self, row) -> None:
        self.app._ghost_btn(row, "Open Azure portal", lambda: webbrowser.open(auth.AZURE_PORTAL_URL), height=36).pack(side="left", expand=True, fill="x", padx=(0, 4))
        self.app._ghost_btn(row, "Mojang approval form", lambda: webbrowser.open(auth.MOJANG_APPROVAL_URL), height=36).pack(side="left", expand=True, fill="x", padx=(4, 0))

    def _save_and_start(self) -> None:
        cid = self.entry.get().strip()
        if len(cid) < 30 or cid.count("-") != 4:
            self._show_setup("That doesn't look like an Application (client) ID (it looks like 12345678-abcd-....).")
            return
        self.app.cfg["ms_client_id"] = cid
        self.app.save()
        self._start()

    def _start(self) -> None:
        self._clear()
        self.cancel.clear()
        self._label("Sign in with Microsoft", 24, bold=True, pady=(0, 10))
        self.status = self._label("Contacting Microsoft...", 14, MUTED)
        threading.Thread(target=self._worker, daemon=True).start()

    def _worker(self) -> None:
        cid = self._client_id()
        try:
            flow = auth.start_device_flow(cid)
            self.app.post(lambda: self._show_code(flow))
            tokens = auth.poll_device_flow(cid, flow, self.cancel)
            self.app.post(lambda: self.status.configure(text="Signing in to Xbox and Minecraft...") if self._alive() else None)
            profile = auth.finish_login(tokens)
            self.app.post(lambda: self._done(profile))
        except auth.AuthError as e:
            msg = str(e)
            if not self.cancel.is_set():
                self.app.post(lambda: self._fail(msg))
        except Exception as e:  # never leave the dialog hanging
            msg = f"Unexpected error: {type(e).__name__}: {e}"
            self.app.post(lambda: self._fail(msg))

    def _show_code(self, flow: dict) -> None:
        if not self._alive():
            return
        self._clear()
        self._label("Sign in with Microsoft", 24, bold=True, pady=(0, 6))
        self._label("On any device (this PC or your phone) open the page below and enter this code:", 13, MUTED)
        box = ctk.CTkFrame(self.body, fg_color=CARD, corner_radius=14)
        box.pack(fill="x", pady=8)
        ctk.CTkLabel(box, text=flow["user_code"], text_color=ACCENT, font=ctk.CTkFont(family=FONT, size=44, weight="bold")).pack(pady=(14, 2))
        ctk.CTkLabel(box, text=flow["verification_uri"].replace("https://", ""), text_color=TEXT,
                     font=ctk.CTkFont(family=FONT, size=15)).pack(pady=(0, 14))
        self._btn("Open the sign-in page", lambda: webbrowser.open(flow["verification_uri"]), accent=True)
        self._btn("Copy code", lambda: (self.clipboard_clear(), self.clipboard_append(flow["user_code"])))
        self.status = self._label("Waiting for you to approve the code...", 13, MUTED, pady=(8, 0))
        webbrowser.open(flow["verification_uri"])

    def _done(self, profile: dict) -> None:
        self.app.on_login_success(profile)
        if self._alive():
            self._close()

    def _fail(self, msg: str) -> None:
        if not self._alive():
            return
        self._clear()
        self._label("Couldn't sign in", 24, bold=True, pady=(0, 8))
        self._label(msg, 14, ACCENT, pady=(0, 14))
        self._btn("Try again", self._start, accent=True)
        self._btn("Change Azure app ID", self._show_setup)
        self._btn("Close", self._close)


class App(ctk.CTk):
    def __init__(self):
        ensure_dirs()
        super().__init__()
        self.cfg = config.load()
        self.q: queue.Queue = queue.Queue()
        self.game_proc = None
        self.busy = False

        ctk.set_appearance_mode("dark")
        self.title(f"{self.cfg['client_name']} {__version__}")
        self.geometry("1120x700")
        self.minsize(960, 640)
        self.configure(fg_color=BG)

        mcfg = self.cfg["music"]
        folder = Path(mcfg["folder"]) if mcfg["folder"] else DEFAULT_MUSIC_DIR
        self.player = MusicPlayer(folder, mcfg["volume"], mcfg["shuffle"])
        self.player.on_change = lambda: self.post(self._refresh_music)
        self.player.scan()
        self.overlay = NowPlayingOverlay(self, FONT)

        self.wall_src = scenery.wallpaper(1920, 1080)
        self.wall_rgb = None
        self.wall_tk = None
        self._size = (0, 0)
        self._dock_cache: dict = {}
        self._dock_pos: dict = {}
        self._hint_img = None
        self._page_bg = None
        self._page_key = None
        self._layout_job = None
        self.hover = None
        self.view = "lock" if self.cfg["lock_screen"] else "home"

        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(0, weight=1)
        self.cv = tk.Canvas(self, highlightthickness=0, bd=0, bg=BG)
        self.cv.grid(row=0, column=0, sticky="nsew")
        self._build_stage()

        self.pages = {
            "Play": self._page_play(),
            "Mods": self._page_mods(),
            "Pack": self._page_pack(),
            "Music": self._page_music(),
            "Settings": self._page_settings(),
        }
        self.protocol("WM_DELETE_WINDOW", self._close)
        self._tick()
        self.after(80, self._pump)
        if mcfg["hotkeys"]:
            self.player.enable_hotkeys()

    # ------------------------------------------------------------------ plumbing
    def post(self, fn) -> None:
        self.q.put(fn)

    def _pump(self) -> None:
        try:
            while True:
                self.q.get_nowait()()
        except queue.Empty:
            pass
        self.after(80, self._pump)

    def log(self, text: str) -> None:
        def _do():
            self.console.configure(state="normal")
            self.console.insert("end", text + "\n")
            self.console.see("end")
            self.console.configure(state="disabled")
        self.post(_do)

    def save(self) -> None:
        config.save(self.cfg)

    # ------------------------------------------------------------------ stage (wallpaper / clock / dock)
    def _build_stage(self) -> None:
        cv = self.cv
        f = lambda size, weight="normal": ctk.CTkFont(family=FONT, size=size, weight=weight)
        self.f_big, self.f_small = f(96), f(46)
        self.f_date, self.f_date_s = f(20), f(15)
        self.f_name, self.f_hint = f(16), f(14, "bold")

        self.wall_item = cv.create_image(0, 0, anchor="nw")

        def text(font, fill):
            return (cv.create_text(0, 0, font=font, fill=SHADOW, state="hidden"),
                    cv.create_text(0, 0, font=font, fill=fill, state="hidden"))

        self.t_date = text(self.f_date, "#ffe6d0")
        self.t_time = text(self.f_big, "#ffffff")
        self.t_name = text(self.f_name, "#ffd6bd")
        self.t_label = text(self.f_name, "#ffffff")
        self.pill_item = cv.create_image(0, 0, anchor="center", state="hidden")
        self.t_pill = cv.create_text(0, 0, anchor="w", font=self.f_hint, fill="#ffffff", state="hidden")
        self._pill_key = None
        self._pill_img = None
        self.hint_item = cv.create_image(0, 0, anchor="center", state="hidden")
        self.t_hint = text(self.f_hint, "#ffffff")
        self.dock_items = [cv.create_image(0, 0, anchor="center", tags=(f"dock{i}",), state="hidden")
                           for i in range(len(DOCK))]

        # glass page card that holds the Play / Mods / Pack / Music / Settings pages
        self.page_bg_item = cv.create_image(0, 0, anchor="center", state="hidden")
        self.page_card = ctk.CTkFrame(cv, fg_color=GLASS, corner_radius=0, border_width=0)
        self.page_win = cv.create_window(0, 0, window=self.page_card, anchor="center", state="hidden")
        self.page_body = ctk.CTkFrame(self.page_card, fg_color="transparent")
        self.page_body.pack(fill="both", expand=True, padx=26, pady=22)
        ctk.CTkButton(self.page_card, text="\u00d7", width=34, height=34, corner_radius=17, fg_color=CARD_HI,
                      hover_color="#4a3a6a", text_color=TEXT, font=ctk.CTkFont(size=22),
                      command=self.close_page).place(relx=1, x=-16, y=16, anchor="ne")

        cv.bind("<Configure>", lambda e: self._debounce_layout())
        cv.bind("<Button-1>", self._on_click)
        self.bind("<Key>", self._on_key)
        for i in range(len(DOCK)):
            tag = f"dock{i}"
            cv.tag_bind(tag, "<Enter>", lambda e, i=i: self._set_hover(i))
            cv.tag_bind(tag, "<Leave>", lambda e: self._set_hover(None))
            cv.tag_bind(tag, "<Button-1>", lambda e, i=i: self._dock_click(i))

    def _debounce_layout(self) -> None:
        if self._layout_job:
            self.after_cancel(self._layout_job)
        self._layout_job = self.after(60, self._layout)

    def _put(self, pair, x, y, text=None, font=None, show=True) -> None:
        for item, dx in ((pair[0], 2), (pair[1], 0)):
            self.cv.coords(item, x + dx, y + dx)
            kw = {"state": "normal" if show else "hidden"}
            if text is not None:
                kw["text"] = text
            if font is not None:
                kw["font"] = font
            self.cv.itemconfigure(item, **kw)

    def _clock_strings(self):
        t = time.localtime()
        return (f"{DAYS[t.tm_wday]}, {t.tm_mday} {MONTHS[t.tm_mon - 1]}", time.strftime("%H:%M", t))

    def _tick(self) -> None:
        date, clock = self._clock_strings()
        for item in self.t_date:
            self.cv.itemconfigure(item, text=date)
        for item in self.t_time:
            self.cv.itemconfigure(item, text=clock)
        self.after(1000, self._tick)

    def _layout(self) -> None:
        self._layout_job = None
        cv = self.cv
        W, H = cv.winfo_width(), cv.winfo_height()
        if W < 100 or H < 100:
            return
        if (W, H) != self._size:
            self._size = (W, H)
            s = max(W / self.wall_src.width, H / self.wall_src.height)
            r = self.wall_src.resize((math.ceil(self.wall_src.width * s), math.ceil(self.wall_src.height * s)), Image.BILINEAR)
            l, t = (r.width - W) // 2, (r.height - H) // 2
            self.wall_rgb = r.crop((l, t, l + W, t + H))
            self.wall_tk = ImageTk.PhotoImage(self.wall_rgb)
            cv.itemconfigure(self.wall_item, image=self.wall_tk)
            for item in (*self.dock_items, self.hint_item, self.page_bg_item):
                cv.itemconfigure(item, image="")      # release before the PhotoImages are dropped
            self._dock_cache.clear()
            self._hint_img = None
            self._page_bg = None
            self._page_key = None
            cv.itemconfigure(self.pill_item, image="")
            self._pill_key = None
            self._pill_img = None

        st = self.view
        date, clock = self._clock_strings()
        name = f"{self.cfg['client_name']}  {self.cfg['mc_version']}"
        show_dock = st == "home"
        for i, item in enumerate(self.dock_items):
            cv.itemconfigure(item, state="normal" if show_dock else "hidden")
        cv.itemconfigure(self.page_win, state="hidden")
        cv.itemconfigure(self.page_bg_item, state="hidden")
        cv.itemconfigure(self.hint_item, state="hidden")
        for pair in (self.t_hint, self.t_name, self.t_label):
            self._put(pair, 0, 0, show=False)

        if st == "lock":
            self._put(self.t_date, W / 2, H * 0.27, date, self.f_date)
            self._put(self.t_time, W / 2, H * 0.385, clock, self.f_big)
            self._put(self.t_name, W / 2, H * 0.52, name)
            pw, ph = 250, 46
            cx, cy = W / 2, H - 76
            self._hint_img = ImageTk.PhotoImage(glass(self.wall_rgb, (cx - pw / 2, cy - ph / 2, cx + pw / 2, cy + ph / 2), 23,
                                                      tint_a=0.2, border=0.5))
            cv.itemconfigure(self.hint_item, image=self._hint_img, state="normal")
            cv.coords(self.hint_item, cx, cy)
            self._put(self.t_hint, cx, cy, "Click to unlock", self.f_hint)
        elif st == "home":
            self._put(self.t_date, W / 2, H * 0.125, date, self.f_date_s)
            self._put(self.t_time, W / 2, H * 0.195, clock, self.f_small)
            self._put(self.t_name, W / 2, H * 0.27, name)
            D, gap = 78, 26
            total = len(DOCK) * D + (len(DOCK) - 1) * gap
            y = H * 0.52
            for i, item in enumerate(self.dock_items):
                x = (W - total) / 2 + D / 2 + i * (D + gap)
                cv.coords(item, x, y)
                self._set_dock_image(i, x, y, D)
            self._update_label()
        else:  # page
            self._put(self.t_date, 0, 0, show=False)
            self._put(self.t_time, 0, 0, show=False)
            pw, ph = min(W - 40, 1060), min(H - 36, 680)
            if self._page_key != (pw, ph):
                box = (W / 2 - pw / 2, H / 2 - ph / 2, W / 2 + pw / 2, H / 2 + ph / 2)
                self._page_bg = ImageTk.PhotoImage(glass(self.wall_rgb, box, 34, tint_a=0.10, dark=0.7, border=0.5))
                self._page_key = (pw, ph)
            cv.itemconfigure(self.page_bg_item, image=self._page_bg, state="normal")
            cv.coords(self.page_bg_item, W / 2, H / 2)
            cv.coords(self.page_win, W / 2, H / 2)
            cv.itemconfigure(self.page_win, width=pw - 36, height=ph - 36, state="normal")
        self._update_pill()

    def _now_playing_text(self) -> str:
        pl = self.player
        cur = pl.current
        if not cur or not (pl.playing or pl.paused):
            return ""
        title = cur.stem if len(cur.stem) <= 38 else cur.stem[:37] + "\u2026"
        return ("Paused  \u00b7  " if pl.paused else "") + title

    def _update_pill(self) -> None:
        """Now-playing pill at the top centre of the launcher (lock + home views)."""
        cv = self.cv
        W, H = self._size
        text = self._now_playing_text()
        if self.view == "page" or not text or W < 100 or self.wall_rgb is None:
            cv.itemconfigure(self.pill_item, state="hidden")
            cv.itemconfigure(self.t_pill, state="hidden")
            return
        key = (text, W, H)
        tw = self.f_hint.measure(text)
        ph, pw = 40, 14 + 22 + 10 + tw + 22
        cx, cy = W / 2, 38
        if key != self._pill_key:
            box = (cx - pw / 2, cy - ph / 2, cx + pw / 2, cy + ph / 2)
            img = glass(self.wall_rgb, box, ph // 2, tint_a=0.22, dark=0.7, border=0.55)
            layer = Image.new("RGBA", (ph * 3, ph * 3), (0, 0, 0, 0))
            _icon("music")(ImageDraw.Draw(layer), ph * 3, ph * 3)
            img.alpha_composite(layer.resize((ph, ph), Image.LANCZOS).resize((int(ph * 0.72),) * 2, Image.LANCZOS), (14, int(ph * 0.14)))
            self._pill_img = ImageTk.PhotoImage(img)
            self._pill_key = key
        cv.itemconfigure(self.pill_item, image=self._pill_img, state="normal")
        cv.coords(self.pill_item, cx, cy)
        cv.coords(self.t_pill, cx - pw / 2 + 14 + 22 + 6, cy)
        cv.itemconfigure(self.t_pill, text=text, state="normal")

    def _set_dock_image(self, i: int, x: float, y: float, D: int) -> None:
        hov = self.hover == i
        key = (i, hov)
        if key not in self._dock_cache:
            box = (x - D / 2, y - D / 2, x + D / 2, y + D / 2)
            img = glass(self.wall_rgb, box, D // 2, tint_a=0.34 if hov else 0.16, dark=0.98 if hov else 0.84,
                        border=0.75 if hov else 0.4, glyph=_icon(DOCK[i][1]))
            self._dock_cache[key] = ImageTk.PhotoImage(img)
        self.cv.itemconfigure(self.dock_items[i], image=self._dock_cache[key])
        self._dock_pos[i] = (x, y, D)

    def _set_hover(self, i) -> None:
        old, self.hover = self.hover, i
        self.cv.configure(cursor="hand2" if i is not None else "")
        for j in {old, i} - {None}:
            x, y, D = self._dock_pos[j]
            self._set_dock_image(j, x, y, D)
        self._update_label()

    def _update_label(self) -> None:
        if self.view == "home" and self.hover is not None:
            x, y, D = self._dock_pos[self.hover]
            self._put(self.t_label, x, y + D / 2 + 24, DOCK[self.hover][0])
        else:
            self._put(self.t_label, 0, 0, show=False)

    def _on_click(self, event) -> None:
        if self.view == "lock":
            self.unlock()

    def _on_key(self, event) -> None:
        if self.view == "lock":
            self.unlock()
        elif event.keysym == "Escape" and self.view == "page":
            self.close_page()

    def _dock_click(self, i: int) -> None:
        if self.view != "home":
            return
        name = DOCK[i][0]
        if name == "Exit":
            self._close()
        else:
            self.open_page(name)

    def unlock(self) -> None:
        self.view = "home"
        self._layout()

    def open_page(self, name: str) -> None:
        self.view = "page"
        for p in self.pages.values():
            p.pack_forget()
        self.pages[name].pack(fill="both", expand=True)
        self._layout()
        if name == "Mods":
            self._refresh_mods()
        if name == "Music":
            self._refresh_music()

    def close_page(self) -> None:
        self.view = "home"
        self._layout()

    # ------------------------------------------------------------------ layout helpers
    def _title(self, parent, title: str, sub: str) -> None:
        ctk.CTkLabel(parent, text=title, font=ctk.CTkFont(size=28, weight="bold"), text_color=TEXT).pack(anchor="w")
        ctk.CTkLabel(parent, text=sub, font=ctk.CTkFont(size=13), text_color=MUTED, justify="left").pack(anchor="w", pady=(2, 16))

    def _card(self, parent, **kw) -> ctk.CTkFrame:
        return ctk.CTkFrame(parent, fg_color=CARD, corner_radius=14, **kw)

    def _slider_row(self, parent, label, lo, hi, value, steps, fmt, on_change):
        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", padx=18, pady=8)
        ctk.CTkLabel(row, text=label, width=190, anchor="w", text_color=TEXT).pack(side="left")
        val = ctk.CTkLabel(row, text=fmt(value), width=70, text_color=ACCENT, font=ctk.CTkFont(weight="bold"))
        val.pack(side="right")

        def cb(v):
            val.configure(text=fmt(v))
            on_change(v)
        s = ctk.CTkSlider(row, from_=lo, to=hi, number_of_steps=steps, command=cb,
                          progress_color=ACCENT, button_color=ACCENT, button_hover_color=ACCENT_HI)
        s.set(value)
        s.pack(side="left", fill="x", expand=True, padx=10)
        return s

    def _accent_btn(self, parent, text, cmd, **kw):
        return ctk.CTkButton(parent, text=text, command=cmd, fg_color=ACCENT, hover_color=ACCENT_HI,
                             text_color="#25110a", font=ctk.CTkFont(size=14, weight="bold"), corner_radius=10, **kw)

    def _ghost_btn(self, parent, text, cmd, **kw):
        return ctk.CTkButton(parent, text=text, command=cmd, fg_color=CARD_HI, hover_color="#2a2a3c",
                             text_color=TEXT, corner_radius=10, **kw)

    # ------------------------------------------------------------------ PLAY
    def _page_play(self):
        page = ctk.CTkFrame(self.page_body, fg_color="transparent")
        self._title(page, "Ready to fight.", "Optimised Fabric client with short swords, low fire, low shield and your music.")

        card = self._card(page)
        card.pack(fill="x")
        row = ctk.CTkFrame(card, fg_color="transparent")
        row.pack(fill="x", padx=18, pady=(16, 6))
        self.var_user = ctk.StringVar(value=self.cfg["username"])
        self.acct_left = ctk.CTkFrame(row, fg_color="transparent", width=400, height=40)
        self.acct_left.pack(side="left")
        self.acct_left.pack_propagate(False)
        self.entry_server = ctk.CTkEntry(row, placeholder_text="Auto-join server (optional), e.g. play.example.net",
                                         placeholder_text_color=MUTED, height=40)
        self.entry_server.pack(side="left", fill="x", expand=True, padx=(12, 0))
        if self.cfg["server"]:
            self.entry_server.insert(0, self.cfg["server"])
        self._refresh_account()

        self.ram_slider = self._slider_row(card, "Memory (RAM)", 2, 16, self.cfg["ram_gb"], 14,
                                           lambda v: f"{int(round(float(v)))} GB", lambda v: None)
        row2 = ctk.CTkFrame(card, fg_color="transparent")
        row2.pack(fill="x", padx=18, pady=(2, 16))
        self.var_full = ctk.BooleanVar(value=self.cfg["fullscreen"])
        ctk.CTkSwitch(row2, text="Start fullscreen", variable=self.var_full, progress_color=ACCENT).pack(side="left")

        self.play_btn = self._accent_btn(page, "PLAY", self._on_play, height=58)
        self.play_btn.configure(font=ctk.CTkFont(size=20, weight="bold"))
        self.play_btn.pack(fill="x", pady=(16, 8))
        self.status = ctk.CTkLabel(page, text="Idle", text_color=MUTED, anchor="w")
        self.status.pack(fill="x")
        self.bar = ctk.CTkProgressBar(page, progress_color=ACCENT, fg_color=CARD, height=8)
        self.bar.set(0)
        self.bar.pack(fill="x", pady=(4, 12))
        self.console = ctk.CTkTextbox(page, fg_color=CARD, text_color=MUTED, corner_radius=12,
                                      font=ctk.CTkFont(family="Consolas", size=12), state="disabled")
        self.console.pack(fill="both", expand=True)
        return page

    def _collect_play_settings(self) -> None:
        self.cfg["username"] = self.var_user.get().strip() or "Player"
        self.cfg["server"] = self.entry_server.get().strip()
        self.cfg["ram_gb"] = int(round(self.ram_slider.get()))
        self.cfg["fullscreen"] = bool(self.var_full.get())
        self.save()

    def _set_status(self, text: str) -> None:
        self.post(lambda: self.status.configure(text=text))

    def _set_progress(self, done: int, total: int) -> None:
        if total:
            self.post(lambda: self.bar.set(min(1.0, done / total)))

    def _on_play(self) -> None:
        if self.busy:
            return
        self._collect_play_settings()
        self.busy = True
        self.play_btn.configure(state="disabled", text="STARTING...")
        threading.Thread(target=self._play_worker, daemon=True).start()

    def _signed_in(self) -> bool:
        return bool(self.cfg["account_type"] == "microsoft" and self.cfg["ms_refresh_token"] and self.cfg["ms_username"])

    def _refresh_account(self) -> None:
        for w in self.acct_left.winfo_children():
            w.destroy()
        if self._signed_in():
            ctk.CTkLabel(self.acct_left, text=f"\u25cf  {self.cfg['ms_username']}", text_color=GOOD,
                         font=ctk.CTkFont(family=FONT, size=15, weight="bold")).pack(side="left", padx=(4, 10))
            self._ghost_btn(self.acct_left, "Sign out", self.sign_out, height=36, width=84).pack(side="right")
        else:
            ctk.CTkEntry(self.acct_left, textvariable=self.var_user, placeholder_text="Offline name", placeholder_text_color=MUTED,
                         height=40, width=150).pack(side="left")
            self._accent_btn(self.acct_left, "Sign in with Microsoft", self.open_login, height=40).pack(side="left", fill="x", expand=True, padx=(8, 0))
        if hasattr(self, "ms_label"):
            self.ms_label.configure(text=self._ms_text(), text_color=GOOD if self._signed_in() else MUTED)

    def open_login(self) -> None:
        LoginDialog(self)

    def on_login_success(self, profile: dict) -> None:
        self.cfg.update(account_type="microsoft", ms_refresh_token=profile.get("refresh_token", ""),
                        ms_username=profile["username"], ms_uuid=profile["uuid"])
        self.save()
        self._refresh_account()
        self.status.configure(text=f"Signed in as {profile['username']}")

    def sign_out(self) -> None:
        self.cfg.update(account_type="offline", ms_refresh_token="", ms_username="", ms_uuid="")
        self.save()
        self._refresh_account()

    def _profile(self) -> dict:
        cfg = self.cfg
        if self._signed_in():
            cid = (cfg["ms_client_id"] or auth.BUNDLED_CLIENT_ID).strip()
            try:
                self.log("Signing in to Microsoft...")
                p = auth.login_with_refresh(cid, cfg["ms_refresh_token"])
                cfg["ms_refresh_token"] = p.get("refresh_token") or cfg["ms_refresh_token"]
                cfg["ms_username"], cfg["ms_uuid"] = p["username"], p["uuid"]
                self.save()
                return p
            except auth.NetworkError as e:
                self.log(f"{e} Playing offline as {cfg['username']} this time.")
        return auth.offline_profile(cfg["username"])

    def _play_worker(self) -> None:
        try:
            self.post(lambda: self.bar.set(0))
            vid = installer.install_game(self.cfg, log=self.log, set_status=self._set_status,
                                         set_progress=self._set_progress)
            self._set_status("Launching...")
            profile = self._profile()
            self.log(f"Starting {vid} as {profile['username']}")
            self.game_proc = installer.launch(self.cfg, vid, profile, on_exit=self._on_game_exit, log=self.log)
            self.post(self._game_started)
        except Exception as e:
            self.log(f"ERROR: {type(e).__name__}: {e}")
            self._set_status("Something went wrong - see log")
            self.post(self._reset_play)

    def _game_started(self) -> None:
        self.status.configure(text="Game running - have fun!")
        self.bar.set(1)
        self.play_btn.configure(text="RUNNING")
        if self.cfg["music"]["autoplay"]:
            self.player.scan()
            self.player.play()
        if self.cfg["music"]["overlay"] and self.game_proc is not None:
            self.overlay.attach(self.game_proc.pid)
            self._refresh_music()
        self.iconify()

    def _on_game_exit(self, code: int) -> None:
        def _do():
            self.log(f"Game closed (exit code {code}). Log: {LOG_DIR / 'game.log'}")
            self.status.configure(text="Game closed" if code == 0 else f"Game crashed (code {code}) - open Logs in Settings")
            if self.cfg["music"]["autoplay"]:
                self.player.stop()
            self.overlay.detach()
            self.deiconify()
            self._reset_play()
        self.post(_do)

    def _reset_play(self) -> None:
        self.busy = False
        self.play_btn.configure(state="normal", text="PLAY")

    # ------------------------------------------------------------------ MODS
    def _page_mods(self):
        page = ctk.CTkFrame(self.page_body, fg_color="transparent")
        self._title(page, "Mods", "Downloaded from Modrinth for your Minecraft version. Refreshed automatically each time you press Play.")
        scroll = ctk.CTkScrollableFrame(page, fg_color=CARD, corner_radius=14)
        scroll.pack(fill="both", expand=True)
        self.mod_vars, self.mod_info = {}, {}
        group = None
        for slot in installer.MOD_SLOTS:
            if slot["group"] != group:
                group = slot["group"]
                ctk.CTkLabel(scroll, text=group.upper(), text_color=ACCENT, font=ctk.CTkFont(size=12, weight="bold")).pack(anchor="w", padx=12, pady=(14, 2))
            row = ctk.CTkFrame(scroll, fg_color="transparent")
            row.pack(fill="x", padx=8, pady=2)
            var = ctk.BooleanVar(value=slot["id"] not in self.cfg["disabled_mods"])
            sw = ctk.CTkSwitch(row, text=slot["name"], variable=var, progress_color=ACCENT,
                               command=self._mods_changed, state="disabled" if slot.get("locked") else "normal")
            sw.pack(side="left")
            info = ctk.CTkLabel(row, text="", text_color=MUTED, font=ctk.CTkFont(size=11))
            info.pack(side="right", padx=8)
            self.mod_vars[slot["id"]], self.mod_info[slot["id"]] = var, info
        bottom = ctk.CTkFrame(page, fg_color="transparent")
        bottom.pack(fill="x", pady=(12, 0))
        self.mods_btn = self._accent_btn(bottom, "Update mods now", self._update_mods_now, height=40)
        self.mods_btn.pack(side="left")
        self._ghost_btn(bottom, "Open mods folder", lambda: open_path(GAME_DIR / "mods"), height=40).pack(side="left", padx=10)
        return page

    def _mods_changed(self) -> None:
        self.cfg["disabled_mods"] = [k for k, v in self.mod_vars.items() if not v.get()]
        self.save()

    def _refresh_mods(self) -> None:
        managed = installer.read_managed()
        by_slot = {m["slot"]: m for m in managed.values()}
        for sid, lab in self.mod_info.items():
            m = by_slot.get(sid)
            lab.configure(text=f"installed  {m['version']}" if m else "not installed yet", text_color=GOOD if m else MUTED)

    def _update_mods_now(self) -> None:
        self.mods_btn.configure(state="disabled", text="Updating...")

        def work():
            installer.sync_mods(self.cfg, self.log, self._set_status)
            self.post(lambda: (self.mods_btn.configure(state="normal", text="Update mods now"), self._refresh_mods(),
                               self.status.configure(text="Mods updated")))
        threading.Thread(target=work, daemon=True).start()

    # ------------------------------------------------------------------ PACK
    def _page_pack(self):
        page = ctk.CTkFrame(self.page_body, fg_color="transparent")
        self._title(page, "PvP Pack", "Short swords, low shield and low fire. Generated from your own game files.\nAdjust, press Rebuild, and it applies next time the game starts.")
        card = self._card(page)
        card.pack(fill="x")
        p = self.cfg["pack"]
        self.var_pack = ctk.BooleanVar(value=p["enabled"])
        ctk.CTkSwitch(card, text="Enable ApexPvP pack", variable=self.var_pack, progress_color=ACCENT,
                      command=lambda: p.__setitem__("enabled", bool(self.var_pack.get()))).pack(anchor="w", padx=18, pady=(16, 4))
        self.var_sunset = ctk.BooleanVar(value=p.get("sunset_menu", True))
        ctk.CTkSwitch(card, text="Sunset panorama on the Minecraft title screen", variable=self.var_sunset,
                      progress_color=ACCENT, command=lambda: p.__setitem__("sunset_menu", bool(self.var_sunset.get()))
                      ).pack(anchor="w", padx=18, pady=(4, 4))
        self._slider_row(card, "Sword size (short swords)", 0.4, 1.0, p["sword_scale"], 12,
                         lambda v: f"x{float(v):.2f}", lambda v: p.__setitem__("sword_scale", round(float(v), 2)))
        self._slider_row(card, "Shield: how low", 0, 12, p["shield_drop"], 24,
                         lambda v: f"{float(v):.1f}", lambda v: p.__setitem__("shield_drop", round(float(v), 1)))
        self._slider_row(card, "Shield size", 0.5, 1.0, p["shield_scale"], 10,
                         lambda v: f"x{float(v):.2f}", lambda v: p.__setitem__("shield_scale", round(float(v), 2)))
        self._slider_row(card, "Fire height (screen)", 0.1, 1.0, p["fire_height"], 18,
                         lambda v: f"{float(v) * 100:.0f}%", lambda v: p.__setitem__("fire_height", round(float(v), 2)))
        ctk.CTkLabel(card, text="", height=6).pack()
        bottom = ctk.CTkFrame(page, fg_color="transparent")
        bottom.pack(fill="x", pady=(14, 0))
        self._accent_btn(bottom, "Save & rebuild pack", self._rebuild_pack, height=40).pack(side="left")
        self.pack_msg = ctk.CTkLabel(bottom, text="", text_color=MUTED)
        self.pack_msg.pack(side="left", padx=14)
        return page

    def _rebuild_pack(self) -> None:
        self.save()
        try:
            installer.build_pack(self.cfg, self.log, force=True)
            jar = installer.MC_DIR / "versions" / self.cfg["mc_version"] / f"{self.cfg['mc_version']}.jar"
            self.pack_msg.configure(text="Pack rebuilt." if jar.exists() else "Saved - the pack is built after the first Play (game files not downloaded yet).",
                                    text_color=GOOD)
        except Exception as e:
            self.pack_msg.configure(text=f"Failed: {e}", text_color=ACCENT)

    # ------------------------------------------------------------------ MUSIC
    def _page_music(self):
        page = ctk.CTkFrame(self.page_body, fg_color="transparent")
        self._title(page, "Music", "Drop mp3 / ogg / wav / flac files in your music folder. They play while Minecraft runs.")
        m = self.cfg["music"]

        top = ctk.CTkFrame(page, fg_color="transparent")
        top.pack(fill="x")
        self.var_folder = ctk.StringVar(value=str(self.player.folder))
        ctk.CTkEntry(top, textvariable=self.var_folder, height=38, state="readonly").pack(side="left", fill="x", expand=True)
        self._ghost_btn(top, "Browse", self._browse_music, height=38, width=80).pack(side="left", padx=(8, 0))
        self._ghost_btn(top, "Open", lambda: open_path(self.player.folder), height=38, width=60).pack(side="left", padx=(8, 0))
        self._ghost_btn(top, "Rescan", self._rescan, height=38, width=70).pack(side="left", padx=(8, 0))

        self.now = ctk.CTkLabel(page, text="", font=ctk.CTkFont(size=16, weight="bold"), text_color=TEXT, anchor="w")
        self.now.pack(fill="x", pady=(14, 4))
        ctrl = ctk.CTkFrame(page, fg_color="transparent")
        ctrl.pack(fill="x")
        self._ghost_btn(ctrl, "Prev", self.player.prev, width=70, height=38).pack(side="left")
        self.play_pause = self._accent_btn(ctrl, "Play", self.player.toggle, width=90, height=38)
        self.play_pause.pack(side="left", padx=8)
        self._ghost_btn(ctrl, "Next", self.player.next, width=70, height=38).pack(side="left")
        vol = ctk.CTkSlider(ctrl, from_=0, to=1, number_of_steps=40, width=170, progress_color=ACCENT,
                            button_color=ACCENT, button_hover_color=ACCENT_HI, command=self._volume)
        vol.set(m["volume"])
        ctk.CTkLabel(ctrl, text="Volume", text_color=MUTED).pack(side="right")
        vol.pack(side="right", padx=8)

        opts = ctk.CTkFrame(page, fg_color="transparent")
        opts.pack(fill="x", pady=(10, 6))
        self.music_vars = {}
        for key, label in (("shuffle", "Shuffle"), ("autoplay", "Start with the game"),
                           ("mute_game_music", "Mute vanilla music"), ("hotkeys", "Global hotkeys"),
                           ("overlay", "Music pill in game")):
            v = ctk.BooleanVar(value=m[key])
            ctk.CTkSwitch(opts, text=label, variable=v, progress_color=ACCENT,
                          command=lambda k=key, var=v: self._music_opt(k, var)).pack(side="left", padx=(0, 16))
            self.music_vars[key] = v
        ctk.CTkLabel(page, text="Hotkeys work inside Minecraft:  Ctrl+Alt+Right = next   Ctrl+Alt+Left = previous   Ctrl+Alt+Space = pause",
                     text_color=MUTED, font=ctk.CTkFont(size=11)).pack(anchor="w")
        self.music_note = ctk.CTkLabel(page, text="", text_color=ACCENT, anchor="w", justify="left")
        self.music_note.pack(fill="x", pady=(4, 0))
        self.track_list = ctk.CTkScrollableFrame(page, fg_color=CARD, corner_radius=14)
        self.track_list.pack(fill="both", expand=True, pady=(8, 0))
        self.track_btns: list = []
        return page

    def _browse_music(self) -> None:
        d = filedialog.askdirectory(initialdir=str(self.player.folder), title="Choose your music folder")
        if d:
            self.cfg["music"]["folder"] = d
            self.player.stop()
            self.player.scan(Path(d))
            self.var_folder.set(d)
            self.save()
            self._refresh_music()

    def _rescan(self) -> None:
        self.player.scan()
        self._refresh_music()

    def _volume(self, v) -> None:
        self.player.set_volume(float(v))
        self.cfg["music"]["volume"] = round(float(v), 2)
        self.save()

    def _music_opt(self, key: str, var) -> None:
        self.cfg["music"][key] = bool(var.get())
        if key == "shuffle":
            self.player.shuffle = bool(var.get())
        if key == "hotkeys":
            (self.player.enable_hotkeys if var.get() else self.player.disable_hotkeys)()
        if key == "overlay" and self.game_proc is not None and self.game_proc.poll() is None:
            if var.get():
                self.overlay.attach(self.game_proc.pid)
                self._refresh_music()
            else:
                self.overlay.detach()
        self.save()

    def _refresh_music(self) -> None:
        pl = self.player
        self.overlay.set_track(self._now_playing_text().replace("Paused  \u00b7  ", ""), pl.paused)
        if self._size != (0, 0):
            self._update_pill()
        if not hasattr(self, "track_list"):
            return
        cur = pl.current
        if len(self.track_btns) != len(pl.tracks) or any(b.cget("text") != f"  {t.stem}" for b, t in zip(self.track_btns, pl.tracks)):
            for b in self.track_btns:
                b.destroy()
            self.track_btns = []
            for i, t in enumerate(pl.tracks):
                b = ctk.CTkButton(self.track_list, text=f"  {t.stem}", anchor="w", height=34, corner_radius=8,
                                  fg_color="transparent", hover_color=CARD_HI, text_color=TEXT,
                                  command=lambda i=i: pl.play_track(i))
                b.pack(fill="x", padx=6, pady=1)
                self.track_btns.append(b)
        for b, t in zip(self.track_btns, pl.tracks):
            b.configure(fg_color=ACCENT if t == cur and (pl.playing or pl.paused) else "transparent")
        if cur and (pl.playing or pl.paused):
            self.now.configure(text=("Playing: " if pl.playing else "Paused: ") + cur.stem)
        elif pl.tracks:
            self.now.configure(text=f"{len(pl.tracks)} songs ready")
        else:
            self.now.configure(text="No songs yet - put audio files in the music folder and press Rescan")
        self.play_pause.configure(text="Pause" if pl.playing else "Play")
        notes = []
        if pl.error:
            notes.append(pl.error)
        if pl.skipped:
            notes.append(f"{len(pl.skipped)} file(s) skipped (m4a/aac/wma/opus not supported - convert to mp3 or ogg).")
        self.music_note.configure(text="  ".join(notes))

    # ------------------------------------------------------------------ SETTINGS
    def _page_settings(self):
        page = ctk.CTkFrame(self.page_body, fg_color="transparent")
        self._title(page, "Settings", "Account, version and maintenance.")
        card = self._card(page)
        card.pack(fill="x")

        r = ctk.CTkFrame(card, fg_color="transparent")
        r.pack(fill="x", padx=18, pady=(16, 4))
        ctk.CTkLabel(r, text="Microsoft account", width=150, anchor="w", text_color=TEXT).pack(side="left")
        self.ms_label = ctk.CTkLabel(r, text=self._ms_text(), anchor="w", justify="left", wraplength=430,
                                     text_color=GOOD if self._signed_in() else MUTED)
        self.ms_label.pack(side="left", fill="x", expand=True)
        self._accent_btn(r, "Sign in", self.open_login, height=36, width=90).pack(side="right", padx=(8, 0))
        self._ghost_btn(r, "Sign out", self.sign_out, height=36, width=90).pack(side="right")

        r = ctk.CTkFrame(card, fg_color="transparent")
        r.pack(fill="x", padx=18, pady=6)
        ctk.CTkLabel(r, text="Azure app ID", width=150, anchor="w", text_color=TEXT).pack(side="left")
        self.entry_cid = ctk.CTkEntry(r, placeholder_text="Application (client) ID - needed once for Microsoft login",
                                      placeholder_text_color=MUTED, height=36)
        self.entry_cid.pack(side="left", fill="x", expand=True)
        if self.cfg["ms_client_id"]:
            self.entry_cid.insert(0, self.cfg["ms_client_id"])
        self._ghost_btn(r, "Save", self._save_cid, height=36, width=70).pack(side="left", padx=(8, 0))

        r = ctk.CTkFrame(card, fg_color="transparent")
        r.pack(fill="x", padx=18, pady=(12, 16))
        ctk.CTkLabel(r, text="Minecraft version", width=150, anchor="w", text_color=TEXT).pack(side="left")
        self.var_ver = ctk.StringVar(value=self.cfg["mc_version"])
        ctk.CTkEntry(r, textvariable=self.var_ver, width=120, height=36).pack(side="left")
        self._ghost_btn(r, "Apply (restart launcher)", self._apply_version, height=36).pack(side="left", padx=8)

        self.var_lock = ctk.BooleanVar(value=self.cfg["lock_screen"])
        ctk.CTkSwitch(page, text="Show the lock screen when the client starts", variable=self.var_lock,
                      progress_color=ACCENT, command=self._lock_changed).pack(anchor="w", pady=(14, 0))
        bottom = ctk.CTkFrame(page, fg_color="transparent")
        bottom.pack(fill="x", pady=(14, 0))
        self._ghost_btn(bottom, "Open game folder", lambda: open_path(GAME_DIR), height=38).pack(side="left")
        self._ghost_btn(bottom, "Open logs", lambda: open_path(LOG_DIR), height=38).pack(side="left", padx=8)
        self._ghost_btn(bottom, "Repair install", self._repair, height=38).pack(side="left")
        return page

    def _lock_changed(self) -> None:
        self.cfg["lock_screen"] = bool(self.var_lock.get())
        self.save()

    def _ms_text(self) -> str:
        if self._signed_in():
            return f"Signed in as {self.cfg['ms_username']}"
        return ("Not signed in - playing offline (works in singleplayer and offline-mode servers). "
                "Premium servers need Microsoft sign-in.")

    def _save_cid(self) -> None:
        self.cfg["ms_client_id"] = self.entry_cid.get().strip()
        self.save()
        self.ms_label.configure(text="Azure app ID saved.", text_color=GOOD)

    def _apply_version(self) -> None:
        self.cfg["mc_version"] = self.var_ver.get().strip() or "1.21.11"
        self.save()
        self.ms_label.configure(text="Saved. Restart the launcher, then press Play to install that version.", text_color=GOOD)

    def _repair(self) -> None:
        installer.repair()
        self.status.configure(text="Next Play will re-verify all game files")

    # ------------------------------------------------------------------ shutdown
    def _close(self) -> None:
        try:
            self._collect_play_settings()
        except Exception:
            pass
        self.overlay.detach()
        self.player.shutdown()
        self.destroy()


def main() -> None:
    App().mainloop()
