"""Procedural pixel-art sunset landscape (original artwork, generated in code).

Used twice:
  * as the launcher wallpaper
  * as the in-game title-screen panorama (6 cube faces) inside the ApexPvP resource pack
"""
from __future__ import annotations

import math
import random

from PIL import Image, ImageChops, ImageDraw, ImageFilter

SKY_STOPS = [  # (position 0 = top .. 1 = horizon, colour)
    (0.00, (30, 20, 74)),
    (0.30, (94, 46, 150)),
    (0.58, (214, 84, 110)),
    (0.80, (255, 138, 72)),
    (0.93, (255, 196, 108)),
    (1.00, (255, 232, 168)),
]


def _lerp(a, b, t):
    return tuple(int(round(a[i] + (b[i] - a[i]) * t)) for i in range(3))


def _sky_color(t: float):
    for (p0, c0), (p1, c1) in zip(SKY_STOPS, SKY_STOPS[1:]):
        if t <= p1:
            return _lerp(c0, c1, (t - p0) / (p1 - p0) if p1 > p0 else 0)
    return SKY_STOPS[-1][1]


def _shift_row_wrap(img: Image.Image, y: int, dx: int) -> None:
    w = img.width
    dx %= w
    if not dx:
        return
    row = img.crop((0, y, w, y + 1))
    img.paste(row.crop((w - dx, 0, w, 1)), (0, y))
    img.paste(row.crop((0, 0, w - dx, 1)), (dx, y))


def render_scene(width: int, height: int, horizon: int, sun_x: float, seed: int = 7,
                 foreground: bool = True, cloud_span: tuple[float, float] | None = None,
                 sun_height: float = 0.12) -> Image.Image:
    """Render at *pixel-art resolution*. Mountains are left/right symmetric around sun_x and periodic
    across the width, so the same picture can wrap around as a panorama."""
    rnd = random.Random(seed)
    W, H = width, height
    img = Image.new("RGB", (W, H))
    d = ImageDraw.Draw(img)

    # sky
    for y in range(horizon):
        d.line([(0, y), (W, y)], fill=_sky_color(y / max(1, horizon - 1)))
    # stars in the deep purple
    for _ in range(W // 5):
        x, y = rnd.randrange(W), rnd.randrange(int(horizon * 0.35))
        c = _lerp(_sky_color(y / horizon), (255, 255, 255), rnd.uniform(0.25, 0.7))
        d.point((x, y), fill=c)

    # sun glow + disc
    glow = Image.new("RGB", (W, H), (0, 0, 0))
    gd = ImageDraw.Draw(glow)
    sy = horizon - int(horizon * sun_height)
    r = max(4, int(horizon * 0.075))
    for k, col in ((r * 5, (90, 40, 10)), (r * 3, (150, 80, 25)), (int(r * 1.8), (220, 140, 50))):
        gd.ellipse([sun_x - k, sy - k, sun_x + k, sy + k], fill=col)
    glow = glow.filter(ImageFilter.GaussianBlur(r * 1.6))
    img = ImageChops.add(img, glow)
    d = ImageDraw.Draw(img)
    d.ellipse([sun_x - r, sy - r, sun_x + r, sy + r], fill=(255, 246, 205))

    # blocky clouds (kept inside cloud_span so they never straddle a cube-face seam)
    lo, hi = cloud_span if cloud_span else (0.0, 1.0)
    for _ in range(max(6, W // 28)):
        cw, ch = rnd.randrange(12, 34), rnd.randrange(2, 4)
        cx = rnd.uniform(lo, hi - cw / W) * W if hi - cw / W > lo else lo * W
        cy = rnd.randrange(int(horizon * 0.18), int(horizon * 0.62))
        warm = cy / horizon
        col = _lerp((190, 90, 170), (255, 150, 95), warm)
        shade = _lerp(col, (90, 40, 120), 0.45)
        d.rectangle([cx, cy, cx + cw, cy + ch], fill=col)
        d.rectangle([cx + 3, cy - 1, cx + cw - 4, cy], fill=col)
        d.rectangle([cx + 2, cy + ch, cx + cw - 2, cy + ch], fill=shade)

    # mountain ranges (far -> near). Only cosine terms => symmetric about sun_x; the minus sign
    # puts a valley at the sun so the sun stays visible.
    layers = [
        (0.30, (150, 82, 140), [(1, 0.30), (2, 0.16), (3, 0.10), (5, 0.06)]),
        (0.20, (96, 52, 112), [(2, 0.30), (3, 0.16), (4, 0.10), (7, 0.05)]),
        (0.10, (52, 30, 76), [(1, 0.20), (3, 0.26), (6, 0.10), (9, 0.04)]),
    ]
    for base, col, terms in layers:
        for x in range(W):
            th = 2 * math.pi * (x - sun_x) / W
            v = -sum(a * math.cos(k * th) for k, a in terms)
            top = horizon - int(horizon * (base + v * 0.35)) // 2 * 2   # stepped, voxel-like
            top = max(2, min(horizon, top))
            d.line([(x, top), (x, horizon)], fill=col)

    if foreground:
        # dark shoreline with blocky trees on both sides
        dark, darker = (24, 16, 40), (16, 10, 30)
        for side in (0, 1):
            x0 = 0 if side == 0 else W
            sgn = 1 if side == 0 else -1
            for i in range(6):
                bw = int(W * (0.16 - i * 0.02))
                bh = int(horizon * (0.26 - i * 0.03))
                d.rectangle([min(x0, x0 + sgn * bw), horizon - bh, max(x0, x0 + sgn * bw), horizon], fill=dark)
            for _ in range(5):
                tx = x0 + sgn * rnd.randrange(int(W * 0.02), int(W * 0.15))
                th_ = rnd.randrange(int(horizon * 0.16), int(horizon * 0.3))
                base_y = horizon - int(horizon * 0.1)
                d.rectangle([tx - 1, base_y - th_, tx, base_y], fill=darker)
                for ly in range(base_y - th_ - 4, base_y - th_ + 4, 2):
                    span = 5 - abs(ly - (base_y - th_)) // 2
                    d.rectangle([tx - span, ly, tx + span, ly + 1], fill=darker)

    # water: mirrored upper half, ripple-shifted, darkened and tinted
    below = H - horizon
    upper = img.crop((0, max(0, horizon - below), W, horizon)).transpose(Image.FLIP_TOP_BOTTOM)
    water = Image.new("RGB", (W, below), (0, 0, 0))
    water.paste(upper, (0, 0))
    for y in range(below):
        _shift_row_wrap(water, y, int(round(1.6 * math.sin(y * 0.9) + 1.0 * math.sin(y * 2.3 + 1))))
    tint = Image.new("RGB", (W, below), (52, 34, 96))
    water = Image.blend(water, tint, 0.38)
    wd = ImageDraw.Draw(water)
    for _ in range(W // 3):                       # glints
        gx, gy = rnd.randrange(W), rnd.randrange(below)
        near_sun = max(0.0, 1 - abs(gx - sun_x) / (W * 0.10))
        c = _lerp((120, 90, 170), (255, 220, 150), near_sun)
        wd.line([(gx, gy), (gx + rnd.randrange(2, 7), gy)], fill=c)
    img.paste(water, (0, horizon))
    return img


def wallpaper(width: int = 1920, height: int = 1080, block: int = 5) -> Image.Image:
    """Launcher background: low-res pixel art scaled up with hard edges."""
    lw, lh = width // block, height // block
    horizon = int(lh * 0.62)
    base = render_scene(lw, lh, horizon, sun_x=lw * 0.5, seed=11, foreground=True, sun_height=0.24)
    return base.resize((lw * block, lh * block), Image.NEAREST)


def panorama_faces(face: int = 1024, block: int = 8) -> list[Image.Image]:
    """Six cube-map faces (panorama_0..5) for the title screen."""
    n = face // block                      # low-res face edge
    horizon = n // 2
    strip = render_scene(n * 4, n, horizon, sun_x=n / 2, seed=23, foreground=False,
                         cloud_span=(0.04, 0.96))
    faces = []
    for i in range(4):
        f = strip.crop((i * n, 0, (i + 1) * n, n))
        # keep clouds/mountains inside faces: nothing to do, the strip is already continuous
        faces.append(f.resize((face, face), Image.NEAREST))
    rnd = random.Random(5)
    top = Image.new("RGB", (n, n), _sky_color(0.0))
    td = ImageDraw.Draw(top)
    for _ in range(n // 2):
        td.point((rnd.randrange(n), rnd.randrange(n)), fill=(200, 190, 240))
    bottom_c = strip.getpixel((0, n - 1))
    bottom = Image.new("RGB", (n, n), bottom_c)
    bd = ImageDraw.Draw(bottom)
    for _ in range(n * 2):
        x, y = rnd.randrange(n), rnd.randrange(n)
        bd.line([(x, y), (x + rnd.randrange(2, 6), y)], fill=_lerp(bottom_c, (90, 64, 150), 0.5))
    faces.append(top.resize((face, face), Image.NEAREST))
    faces.append(bottom.resize((face, face), Image.NEAREST))
    return faces


if __name__ == "__main__":
    import sys
    out = sys.argv[1] if len(sys.argv) > 1 else "."
    wallpaper(1600, 900).save(f"{out}/wallpaper.png")
    fs = panorama_faces(256, 2)
    strip = Image.new("RGB", (256 * 4, 256))
    for i in range(4):
        strip.paste(fs[i], (i * 256, 0))
    strip.save(f"{out}/panorama_strip.png")
