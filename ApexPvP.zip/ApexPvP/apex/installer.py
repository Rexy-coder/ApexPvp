"""Installs Minecraft + Fabric + performance/HUD mods + the ApexPvP pack, and starts the game."""
from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
import threading
from pathlib import Path

import minecraft_launcher_lib as mll

from . import __version__, modrinth, pack
from .paths import GAME_DIR, LOG_DIR, MC_DIR, ensure_dirs

# --------------------------------------------------------------------------- mod slots
# 'slugs' are tried in order; 'search' is a fallback query (top compatible, non-cheat hit wins).
MOD_SLOTS = [
    {"id": "fabric-api", "name": "Fabric API", "group": "Core", "slugs": ["fabric-api"], "locked": True},
    {"id": "sodium", "name": "Sodium (rendering, big FPS boost)", "group": "Performance", "slugs": ["sodium"]},
    {"id": "lithium", "name": "Lithium (game logic optimisation)", "group": "Performance", "slugs": ["lithium"]},
    {"id": "ferrite-core", "name": "FerriteCore (less RAM)", "group": "Performance", "slugs": ["ferrite-core"]},
    {"id": "entityculling", "name": "Entity Culling", "group": "Performance", "slugs": ["entityculling"]},
    {"id": "immediatelyfast", "name": "ImmediatelyFast (faster HUD/UI)", "group": "Performance", "slugs": ["immediatelyfast"]},
    {"id": "modernfix", "name": "ModernFix (faster start-up)", "group": "Performance", "slugs": ["modernfix"]},
    {"id": "sodium-extra", "name": "Sodium Extra (FPS/coords overlay + video options)", "group": "HUD", "slugs": ["sodium-extra"]},
    {"id": "hud-keystrokes", "name": "Keystrokes HUD", "group": "HUD", "slugs": [], "search": "keystrokes"},
    {"id": "hud-cps", "name": "CPS counter HUD", "group": "HUD", "slugs": [], "search": "cps counter"},
    {"id": "hud-armor", "name": "Armor / durability HUD", "group": "HUD", "slugs": [], "search": "armor status hud"},
    {"id": "hud-health", "name": "Mob / player health above nametags", "group": "HUD", "slugs": [], "search": "health bar mob nametag"},
    {"id": "modmenu", "name": "Mod Menu", "group": "Utility", "slugs": ["modmenu"]},
]

# Trimmed "Aikar-style" G1GC flags: smoother frame times in fights.
JVM_FLAGS = [
    "-XX:+UseG1GC", "-XX:+ParallelRefProcEnabled", "-XX:MaxGCPauseMillis=100",
    "-XX:+UnlockExperimentalVMOptions", "-XX:+DisableExplicitGC", "-XX:+PerfDisableSharedMem",
    "-XX:G1NewSizePercent=30", "-XX:G1MaxNewSizePercent=40", "-XX:G1HeapRegionSize=8M",
    "-XX:G1ReservePercent=20", "-XX:G1HeapWastePercent=5", "-XX:G1MixedGCCountTarget=4",
    "-XX:InitiatingHeapOccupancyPercent=15", "-XX:G1MixedGCLiveThresholdPercent=90",
    "-XX:G1RSetUpdatingPauseTimePercent=5", "-XX:SurvivorRatio=32", "-XX:MaxTenuringThreshold=1",
]

MANAGED_FILE = GAME_DIR / "mods" / ".apex-managed.json"


class Cancelled(Exception):
    pass


# --------------------------------------------------------------------------- helpers
def _marker(mc: str) -> Path:
    return MC_DIR / "versions" / mc / ".apex_ok"


def installed_fabric_id(mc: str) -> str | None:
    vdir = MC_DIR / "versions"
    if not vdir.exists():
        return None
    found = sorted(
        d.name for d in vdir.iterdir()
        if d.name.startswith("fabric-loader-") and d.name.endswith("-" + mc) and (d / f"{d.name}.json").exists()
    )
    return found[-1] if found else None


def _bundled_java(mc: str) -> str | None:
    """Path to the Java that ships with the game download (the Fabric installer needs a JVM)."""
    try:
        data = json.loads((MC_DIR / "versions" / mc / f"{mc}.json").read_text(encoding="utf-8"))
        component = data["javaVersion"]["component"]
        return mll.runtime.get_executable_path(component, str(MC_DIR))
    except Exception:
        return None


def read_managed() -> dict:
    try:
        return json.loads(MANAGED_FILE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def repair() -> None:
    """Forget install markers so the next Play re-verifies every file."""
    for m in (MC_DIR / "versions").glob("*/.apex_ok"):
        m.unlink(missing_ok=True)


# --------------------------------------------------------------------------- install
def install_game(cfg: dict, log=print, set_status=lambda s: None, set_progress=lambda done, total: None) -> str:
    """Make sure everything is installed. Returns the Fabric version id to launch."""
    ensure_dirs()
    mc = cfg["mc_version"]
    total = {"max": 0}

    cb = {
        "setStatus": lambda s: set_status(s),
        "setMax": lambda m: total.__setitem__("max", m),
        "setProgress": lambda p: set_progress(p, total["max"]),
    }

    fabric_id = installed_fabric_id(mc)
    if not _marker(mc).exists() or not fabric_id:
        set_status(f"Downloading Minecraft {mc}")
        log(f"Installing Minecraft {mc} (first run downloads ~500 MB)...")
        mll.install.install_minecraft_version(mc, str(MC_DIR), callback=cb)
        if not fabric_id:
            set_status("Installing Fabric loader")
            log("Installing Fabric loader...")
            loader = mll.mod_loader.get_mod_loader("fabric")
            if not loader.is_minecraft_version_supported(mc):
                raise RuntimeError(f"Fabric does not support Minecraft {mc} yet.")
            fabric_id = loader.install(mc, str(MC_DIR), callback=cb, java=_bundled_java(mc))
        _marker(mc).write_text("ok")

    sync_mods(cfg, log, set_status)
    build_pack(cfg, log)
    return fabric_id


def sync_mods(cfg: dict, log=print, set_status=lambda s: None) -> None:
    mc = cfg["mc_version"]
    mods_dir = GAME_DIR / "mods"
    mods_dir.mkdir(parents=True, exist_ok=True)
    disabled = set(cfg.get("disabled_mods", []))
    set_status("Updating mods")
    log("Checking Modrinth for mods...")
    try:
        wanted: dict[str, dict] = {}
        for slot in MOD_SLOTS:
            if slot["id"] in disabled and not slot.get("locked"):
                continue
            res = modrinth.resolve_slot(slot, mc, log)
            if not res:
                log(f"  - {slot['name']}: no Fabric build for {mc} yet, skipped")
                continue
            ref, version = res
            wanted[ref["project_id"]] = {"slot": slot["id"], "version": version, "name": slot["name"]}
            queue = [version]
            while queue:  # required dependencies, transitively
                for dref, dv in modrinth.required_dependencies(queue.pop(), mc):
                    if dref["project_id"] not in wanted:
                        wanted[dref["project_id"]] = {"slot": "dependency", "version": dv, "name": dv["name"]}
                        queue.append(dv)

        old = read_managed()
        new = {}
        for pid, item in wanted.items():
            f = modrinth.primary_file(item["version"])
            modrinth.download(f, mods_dir / f["filename"])
            new[pid] = {"file": f["filename"], "slot": item["slot"], "name": item["name"],
                        "version": item["version"].get("version_number", "")}
            log(f"  + {item['name']} {new[pid]['version']}")
        for pid, meta in old.items():
            if new.get(pid, {}).get("file") != meta.get("file"):
                (mods_dir / meta["file"]).unlink(missing_ok=True)
        MANAGED_FILE.write_text(json.dumps(new, indent=2), encoding="utf-8")
    except (modrinth.ModrinthError, OSError) as e:
        log(f"Could not update mods ({e}). Using what is already installed.")
    except Exception as e:  # network down etc. - never block playing
        log(f"Could not update mods ({type(e).__name__}: {e}). Using what is already installed.")


def build_pack(cfg: dict, log=print, force: bool = False) -> None:
    pcfg = cfg["pack"]
    pack_dir = GAME_DIR / "resourcepacks" / pack.PACK_NAME
    if not pcfg.get("enabled", True):
        if pack_dir.exists():
            import shutil
            shutil.rmtree(pack_dir)
        return
    jar = MC_DIR / "versions" / cfg["mc_version"] / f"{cfg['mc_version']}.jar"
    if not jar.exists():
        log("Pack: Minecraft jar not installed yet, will build after install.")
        return
    st = jar.stat()
    stamp = hashlib.sha1(json.dumps([pcfg, st.st_mtime_ns, st.st_size, __version__], sort_keys=True).encode()).hexdigest()
    stamp_file = pack_dir / ".apex_hash"
    if not force and stamp_file.exists() and stamp_file.read_text() == stamp:
        return                                   # unchanged since last build
    log("Building ApexPvP pack (short swords / low shield / low fire / sunset menu)...")
    pack.build(pack_dir, jar, pcfg, log)
    stamp_file.write_text(stamp)


# --------------------------------------------------------------------------- launch
def build_command(cfg: dict, version_id: str, profile: dict) -> list[str]:
    ram = max(2, int(cfg["ram_gb"]))
    opts = {
        "username": profile["username"],
        "uuid": profile["uuid"],
        "token": profile["token"],
        "gameDirectory": str(GAME_DIR),
        "launcherName": "ApexPvP",
        "launcherVersion": __version__,
        "jvmArguments": [f"-Xmx{ram}G", f"-Xms{min(ram, 2)}G"] + JVM_FLAGS,
    }
    server = cfg.get("server", "").strip()
    if server:
        opts["quickPlayPath"] = str(LOG_DIR / "quickplay.json")
        opts["quickPlayMultiplayer"] = server
    cmd = mll.command.get_minecraft_command(version_id, str(MC_DIR), opts)
    if cfg.get("fullscreen"):
        cmd.append("--fullscreen")
    return cmd


def launch(cfg: dict, version_id: str, profile: dict, on_exit=lambda code: None, log=print) -> subprocess.Popen:
    pack.update_options(
        GAME_DIR,
        enable_pack=cfg["pack"].get("enabled", True),
        mute_music=cfg["music"].get("mute_game_music", True),
        log=log,
    )
    cmd = build_command(cfg, version_id, profile)
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    logfile = open(LOG_DIR / "game.log", "w", encoding="utf-8", errors="replace")
    flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
    proc = subprocess.Popen(cmd, cwd=str(GAME_DIR), stdout=logfile, stderr=subprocess.STDOUT, creationflags=flags)

    def waiter():
        code = proc.wait()
        logfile.close()
        on_exit(code)

    threading.Thread(target=waiter, daemon=True).start()
    return proc
