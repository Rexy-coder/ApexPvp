"""Persistent user settings (JSON)."""
import copy
import json

from .paths import CONFIG_FILE, ROOT

DEFAULTS = {
    "client_name": "ApexPvP",
    "lock_screen": True,
    "mc_version": "1.21.11",
    "username": "Player",
    "ram_gb": 4,
    "fullscreen": False,
    "server": "",
    "account_type": "offline",           # "offline" | "microsoft"
    "ms_client_id": "",
    "ms_refresh_token": "",
    "ms_username": "",
    "ms_uuid": "",
    "fabric_version_id": "",
    "pack": {
        "enabled": True,
        "sword_scale": 0.75,    # 1.0 = vanilla size, smaller = shorter sword
        "shield_drop": 5.0,     # how far the shield sits lower on screen (display units)
        "shield_scale": 0.85,   # 1.0 = vanilla size
        "fire_height": 0.35,    # fraction of the screen the fire overlay may cover
        "sunset_menu": True,    # sunset panorama behind the Minecraft title screen
    },
    "music": {
        "folder": "",           # empty -> <app folder>/music
        "volume": 0.5,
        "shuffle": True,
        "autoplay": True,       # start music when the game starts
        "mute_game_music": True,
        "hotkeys": True,
        "overlay": True,        # now-playing pill on top of the Minecraft window
    },
    "disabled_mods": [],
}


def _merge(base: dict, over: dict) -> dict:
    out = copy.deepcopy(base)
    for k, v in over.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _merge(out[k], v)
        else:
            out[k] = v
    return out


def load() -> dict:
    try:
        data = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
        return _merge(DEFAULTS, data)
    except (OSError, ValueError):
        return copy.deepcopy(DEFAULTS)


def save(cfg: dict) -> None:
    ROOT.mkdir(parents=True, exist_ok=True)
    tmp = CONFIG_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
    tmp.replace(CONFIG_FILE)
