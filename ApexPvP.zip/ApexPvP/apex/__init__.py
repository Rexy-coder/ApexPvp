"""ApexPvP - a standalone PvP-focused Minecraft Java launcher/client."""
__version__ = "1.0.0"
