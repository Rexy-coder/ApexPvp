"""Accounts: offline names, and Microsoft sign-in done entirely inside the launcher.

Microsoft sign-in uses the OAuth *device code* flow: the launcher shows a short code, the user
approves it at microsoft.com/link (on this PC or on a phone), and the launcher finishes the
Xbox -> Minecraft token exchange by itself. No browser redirect or local web server is needed.

Microsoft/Mojang require every launcher to have its own registered "Azure application" (free, one
time, approved by Mojang). Put its Application (client) ID into Settings, or into BUNDLED_CLIENT_ID
below if you ship a build for other people.
"""
from __future__ import annotations

import hashlib
import threading
import time
import uuid

import requests

BUNDLED_CLIENT_ID = ""      # <- your approved Azure application (client) ID can go here

TENANT = "consumers"
SCOPE = "XboxLive.signin offline_access"
DEVICE_URL = f"https://login.microsoftonline.com/{TENANT}/oauth2/v2.0/devicecode"
TOKEN_URL = f"https://login.microsoftonline.com/{TENANT}/oauth2/v2.0/token"
XBL_URL = "https://user.auth.xboxlive.com/user/authenticate"
XSTS_URL = "https://xsts.auth.xboxlive.com/xsts/authorize"
MC_LOGIN_URL = "https://api.minecraftservices.com/authentication/login_with_xbox"
MC_PROFILE_URL = "https://api.minecraftservices.com/minecraft/profile"

AZURE_PORTAL_URL = "https://portal.azure.com/#view/Microsoft_AAD_RegisteredApps/ApplicationsListBlade"
MOJANG_APPROVAL_URL = "https://aka.ms/mce-reviewappid"

XSTS_ERRORS = {
    2148916233: "This Microsoft account has no Xbox profile yet. Sign in once at xbox.com to create it, then try again.",
    2148916235: "Xbox Live isn't available in your country/region.",
    2148916236: "This account needs adult verification on Xbox before it can be used.",
    2148916237: "This account needs adult verification on Xbox before it can be used.",
    2148916238: "This is a child account. An adult has to add it to a Microsoft Family before it can play.",
}


class AuthError(Exception):
    """Message is safe to show to the user."""


class NetworkError(AuthError):
    """Microsoft/Mojang could not be reached at all (as opposed to rejecting the sign-in)."""


def offline_uuid(name: str) -> str:
    """Same UUID the game itself derives for offline players."""
    h = bytearray(hashlib.md5(("OfflinePlayer:" + name).encode("utf-8")).digest())
    h[6] = (h[6] & 0x0F) | 0x30
    h[8] = (h[8] & 0x3F) | 0x80
    return str(uuid.UUID(bytes=bytes(h)))


def offline_profile(name: str) -> dict:
    name = "".join(c for c in name if c.isalnum() or c == "_")[:16] or "Player"
    return {"username": name, "uuid": offline_uuid(name), "token": "0"}


# ------------------------------------------------------------------ Microsoft
def _post(url: str, **kw) -> requests.Response:
    try:
        return requests.post(url, timeout=25, **kw)
    except requests.RequestException as e:
        raise NetworkError(f"Can't reach Microsoft ({type(e).__name__}). Check your internet connection.") from e


def _json(r: requests.Response) -> dict:
    try:
        data = r.json()
        return data if isinstance(data, dict) else {}
    except ValueError:
        return {}


def _oauth_error(data: dict) -> AuthError:
    err = data.get("error", "unknown_error")
    desc = (data.get("error_description") or "").split("\r\n")[0]
    if "AADSTS700016" in desc or err in ("unauthorized_client", "invalid_client"):
        return AuthError("Microsoft doesn't recognise this Azure application ID. Check that you copied the "
                         "'Application (client) ID' and that the app supports personal Microsoft accounts.")
    if "AADSTS70002" in desc or "AADSTS7000218" in desc:
        return AuthError("In the Azure app, open Authentication and switch 'Allow public client flows' to Yes.")
    return AuthError(f"Microsoft sign-in failed: {desc or err}")


def start_device_flow(client_id: str) -> dict:
    """Returns {'user_code', 'verification_uri', 'device_code', 'interval', 'expires_in'}."""
    if not client_id:
        raise AuthError("No Azure application ID set yet.")
    r = _post(DEVICE_URL, data={"client_id": client_id, "scope": SCOPE})
    data = _json(r)
    if "user_code" not in data:
        raise _oauth_error(data)
    data.setdefault("verification_uri", "https://www.microsoft.com/link")
    data.setdefault("interval", 5)
    return data


def poll_device_flow(client_id: str, flow: dict, cancel: threading.Event | None = None) -> dict:
    """Blocks until the user approves the code. Returns the Microsoft token response."""
    interval = int(flow.get("interval", 5))
    deadline = time.monotonic() + int(flow.get("expires_in", 900))
    while time.monotonic() < deadline:
        if cancel is not None:
            if cancel.wait(interval):
                raise AuthError("Sign-in cancelled.")
        else:
            time.sleep(interval)
        r = _post(TOKEN_URL, data={
            "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
            "client_id": client_id,
            "device_code": flow["device_code"],
        })
        data = _json(r)
        if "access_token" in data:
            return data
        err = data.get("error")
        if err == "authorization_pending":
            continue
        if err == "slow_down":
            interval += 5
            continue
        if err in ("expired_token", "bad_verification_code"):
            raise AuthError("The code expired. Start the sign-in again.")
        if err == "authorization_declined":
            raise AuthError("Sign-in was declined.")
        raise _oauth_error(data)
    raise AuthError("The code expired. Start the sign-in again.")


def _xbox_chain(ms_access_token: str) -> dict:
    """Microsoft token -> Xbox Live -> XSTS -> Minecraft access token + profile."""
    headers = {"Content-Type": "application/json", "Accept": "application/json"}
    r = _post(XBL_URL, headers=headers, json={
        "Properties": {"AuthMethod": "RPS", "SiteName": "user.auth.xboxlive.com", "RpsTicket": f"d={ms_access_token}"},
        "RelyingParty": "http://auth.xboxlive.com", "TokenType": "JWT"})
    xbl = _json(r)
    try:
        xbl_token, uhs = xbl["Token"], xbl["DisplayClaims"]["xui"][0]["uhs"]
    except (KeyError, IndexError):
        raise AuthError("Xbox Live rejected the sign-in. Try again in a minute.")

    r = _post(XSTS_URL, headers=headers, json={
        "Properties": {"SandboxId": "RETAIL", "UserTokens": [xbl_token]},
        "RelyingParty": "rp://api.minecraftservices.com/", "TokenType": "JWT"})
    xsts = _json(r)
    if "Token" not in xsts:
        raise AuthError(XSTS_ERRORS.get(xsts.get("XErr"), f"Xbox rejected the sign-in (code {xsts.get('XErr', r.status_code)})."))

    r = _post(MC_LOGIN_URL, headers=headers, json={"identityToken": f"XBL3.0 x={uhs};{xsts['Token']}"})
    mc = _json(r)
    if "access_token" not in mc:
        raise AuthError("Mojang has not approved this Azure application for Minecraft yet. Apply once at "
                        f"{MOJANG_APPROVAL_URL} (approval can take a few days), then sign in again.")

    try:
        pr = requests.get(MC_PROFILE_URL, headers={"Authorization": f"Bearer {mc['access_token']}"}, timeout=25)
    except requests.RequestException as e:
        raise NetworkError(f"Can't reach Minecraft services ({type(e).__name__}). Check your internet connection.") from e
    profile = _json(pr)
    if "id" not in profile:
        if profile.get("error") == "NOT_FOUND" or pr.status_code == 404:
            raise AuthError("This Microsoft account doesn't own Minecraft: Java Edition.")
        raise AuthError("Couldn't read the Minecraft profile for this account.")
    return {"username": profile["name"], "uuid": profile["id"], "token": mc["access_token"]}


def finish_login(ms_tokens: dict) -> dict:
    """Turn Microsoft tokens into a launch profile (username, uuid, token) + refresh_token to store."""
    profile = _xbox_chain(ms_tokens["access_token"])
    profile["refresh_token"] = ms_tokens.get("refresh_token", "")
    return profile


def login_with_refresh(client_id: str, refresh_token: str) -> dict:
    r = _post(TOKEN_URL, data={"grant_type": "refresh_token", "client_id": client_id,
                               "refresh_token": refresh_token, "scope": SCOPE})
    data = _json(r)
    if "access_token" not in data:
        if data.get("error") == "invalid_grant":
            raise AuthError("Your Microsoft session expired. Please sign in again.")
        raise _oauth_error(data)
    data.setdefault("refresh_token", refresh_token)
    return finish_login(data)
