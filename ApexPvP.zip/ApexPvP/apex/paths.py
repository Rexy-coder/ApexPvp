"""Filesystem locations used by the client."""
import os
import sys
from pathlib import Path

if getattr(sys, "frozen", False):          # PyInstaller build
    APP_DIR = Path(sys.executable).resolve().parent
else:
    APP_DIR = Path(__file__).resolve().parent.parent


def _data_root() -> Path:
    if os.name == "nt":
        base = Path(os.environ.get("APPDATA", str(Path.home())))
    elif sys.platform == "darwin":
        base = Path.home() / "Library" / "Application Support"
    else:
        base = Path(os.environ.get("XDG_DATA_HOME", str(Path.home() / ".local" / "share")))
    return base / "ApexPvP"


ROOT = _data_root()
MC_DIR = ROOT / "minecraft"      # versions, libraries, assets, java runtime
GAME_DIR = ROOT / "game"         # mods, resourcepacks, saves, options.txt
LOG_DIR = ROOT / "logs"
CONFIG_FILE = ROOT / "config.json"
# When started from ApexPvP.exe the app files live in a hidden data folder, so put the
# music folder somewhere the user can find it: Music\ApexPvP.
DEFAULT_MUSIC_DIR = (Path.home() / "Music" / "ApexPvP") if os.environ.get("APEX_EMBEDDED") else (APP_DIR / "music")


def ensure_dirs() -> None:
    for d in (ROOT, MC_DIR, GAME_DIR, GAME_DIR / "mods", GAME_DIR / "resourcepacks", LOG_DIR, DEFAULT_MUSIC_DIR):
        d.mkdir(parents=True, exist_ok=True)
