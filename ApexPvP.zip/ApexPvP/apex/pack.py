"""Generates the "ApexPvP" resource pack straight from the vanilla client jar:

  * short swords  - every sword model gets smaller hand transforms
  * low shield    - shield (and blocking shield) sits lower / smaller in first person
  * low fire      - the on-screen fire overlay only covers the bottom part of the screen

Because everything is derived from the real game files at build time, the numbers stay
correct for whatever Minecraft version is installed, and nothing copyrighted is shipped.
"""
from __future__ import annotations

import copy
import io
import json
import shutil
import zipfile
from pathlib import Path

from PIL import Image, ImageDraw

from . import scenery

PACK_NAME = "ApexPvP"
SWORDS = ["wooden", "stone", "copper", "iron", "golden", "diamond", "netherite"]
FIRST_PERSON = ("firstperson_righthand", "firstperson_lefthand")
HAND_KEYS = FIRST_PERSON + ("thirdperson_righthand", "thirdperson_lefthand")


class _Jar:
    def __init__(self, path: Path):
        self.z = zipfile.ZipFile(path)
        self.names = set(self.z.namelist())

    def has(self, name: str) -> bool:
        return name in self.names

    def bytes(self, name: str) -> bytes | None:
        return self.z.read(name) if name in self.names else None

    def json(self, name: str):
        raw = self.bytes(name)
        return json.loads(raw.decode("utf-8")) if raw else None

    def close(self):
        self.z.close()


def _model_path(model_id: str) -> str:
    return "assets/minecraft/models/" + model_id.replace("minecraft:", "") + ".json"


def _resolved_display(jar: _Jar, model_id: str) -> dict:
    """Walk the parent chain and merge 'display' blocks the way the game does (per key)."""
    chain, cur = [], model_id
    for _ in range(12):
        data = jar.json(_model_path(cur))
        if data is None:
            break
        chain.append(data)
        parent = data.get("parent")
        if not parent:
            break
        cur = parent
    display: dict = {}
    for data in reversed(chain):
        display.update(copy.deepcopy(data.get("display", {})))
    return display


# Only used if the client jar carries no display transforms for the shield model.
_SHIELD_FALLBACK = {
    "thirdperson_lefthand": {"rotation": [0, 90, 0], "translation": [10, 6, -4], "scale": [1, 1, 1]},
    "thirdperson_righthand": {"rotation": [0, 90, 0], "translation": [10, 2, -4], "scale": [1, 1, 1]},
    "firstperson_lefthand": {"rotation": [0, 180, 5], "translation": [-10, 0, -10], "scale": [1.25, 1.25, 1.25]},
    "firstperson_righthand": {"rotation": [0, 180, 5], "translation": [10, 0, -10], "scale": [1.25, 1.25, 1.25]},
    "gui": {"rotation": [15, -25, -5], "translation": [2, 3, 0], "scale": [0.65, 0.65, 0.65]},
    "fixed": {"rotation": [0, 180, 0], "translation": [-2, 4, -5], "scale": [0.5, 0.5, 0.5]},
    "ground": {"rotation": [0, 0, 0], "translation": [4, 4, 2], "scale": [0.25, 0.25, 0.25]},
}


def _write_json(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2), encoding="utf-8")


def pack_format_of(jar: _Jar) -> int:
    info = jar.json("version.json") or {}
    pv = info.get("pack_version")
    if isinstance(pv, dict):
        for key in ("resource_major", "resource"):
            if key in pv:
                return int(pv[key])
    elif isinstance(pv, int):
        return pv
    return 75


def _icon(path: Path) -> None:
    im = Image.new("RGBA", (128, 128), (18, 18, 24, 255))
    d = ImageDraw.Draw(im)
    d.polygon([(28, 100), (40, 112), (104, 40), (92, 28)], fill=(255, 70, 85, 255))   # blade
    d.polygon([(20, 92), (36, 108), (28, 116), (12, 100)], fill=(200, 200, 210, 255))  # guard/grip
    im.save(path)


def build(pack_dir: Path, jar_path: Path, cfg: dict, log=print) -> None:
    """(Re)build the resource pack folder at pack_dir."""
    if pack_dir.exists():
        shutil.rmtree(pack_dir)
    pack_dir.mkdir(parents=True)
    jar = _Jar(jar_path)
    try:
        fmt = pack_format_of(jar)
        _write_json(pack_dir / "pack.mcmeta", {"pack": {
            "pack_format": fmt, "min_format": fmt, "max_format": fmt,
            "description": "ApexPvP - short swords, low shield, low fire",
        }})
        _icon(pack_dir / "pack.png")
        models = pack_dir / "assets" / "minecraft" / "models" / "item"

        # ---- short swords ----
        s = float(cfg["sword_scale"])
        base = _resolved_display(jar, "minecraft:item/handheld")
        made = 0
        for mat in SWORDS:
            mid = f"minecraft:item/{mat}_sword"
            model = jar.json(_model_path(mid))
            if not model:
                continue
            disp = _resolved_display(jar, mid) or copy.deepcopy(base)
            for key in HAND_KEYS:
                t = disp.get(key) or base.get(key)
                if not t:
                    continue
                t = copy.deepcopy(t)
                t["scale"] = [round(v * s, 4) for v in t.get("scale", [1, 1, 1])]
                disp[key] = t
            model["display"] = disp
            _write_json(models / f"{mat}_sword.json", model)
            made += 1
        log(f"  swords: {made} models shortened (scale x{s:.2f})" if made else "  (!) swords: no sword models found in the client jar - not applied")

        # ---- low shield ----
        drop, sscale = float(cfg["shield_drop"]), float(cfg["shield_scale"])
        made = 0
        for name in ("shield", "shield_blocking"):
            mid = f"minecraft:item/{name}"
            model = jar.json(_model_path(mid)) or {"parent": "minecraft:builtin/entity"}
            disp = _resolved_display(jar, mid)
            if not disp:
                disp = copy.deepcopy(_SHIELD_FALLBACK)   # transforms live elsewhere in this version
                model.setdefault("gui_light", "front")
            for key in FIRST_PERSON:
                t = disp.get(key)
                if not t:
                    continue
                tr = list(t.get("translation", [0, 0, 0]))
                tr[1] = round(tr[1] - drop, 3)
                t["translation"] = tr
                t["scale"] = [round(v * sscale, 4) for v in t.get("scale", [1, 1, 1])]
            model["display"] = disp
            _write_json(models / f"{name}.json", model)
            made += 1
        log(f"  shield: {made} models lowered (drop {drop}, scale x{sscale:.2f})" if made else "  (!) shield: shield model not found in the client jar - not applied")

        # ---- low fire ----
        raw = jar.bytes("assets/minecraft/textures/block/fire_1.png")
        if raw:
            im = Image.open(io.BytesIO(raw)).convert("RGBA")
            w, h = im.size
            frames = max(1, h // w)
            cut = w - max(1, round(w * float(cfg["fire_height"])))
            for f in range(frames):
                y0 = f * w
                im.paste((0, 0, 0, 0), (0, y0, w, y0 + cut))
            out = pack_dir / "assets" / "minecraft" / "textures" / "block"
            out.mkdir(parents=True, exist_ok=True)
            im.save(out / "fire_1.png")
            meta = jar.bytes("assets/minecraft/textures/block/fire_1.png.mcmeta")
            if meta:
                (out / "fire_1.png.mcmeta").write_bytes(meta)
            log(f"  fire: overlay limited to bottom {float(cfg['fire_height']) * 100:.0f}% of frame")
        else:
            log("  (!) fire: fire_1.png not found in the client jar - not applied")

        # ---- sunset title-screen panorama ----
        if cfg.get("sunset_menu", True):
            out = pack_dir / "assets" / "minecraft" / "textures" / "gui" / "title" / "background"
            out.mkdir(parents=True, exist_ok=True)
            for i, face in enumerate(scenery.panorama_faces(1024, 8)):
                face.save(out / f"panorama_{i}.png")
            log("  menu: sunset panorama for the Minecraft title screen")
    finally:
        jar.close()


# ---------------------------------------------------------------- options.txt

FRESH_OPTIONS = {
    "maxFps": "260",
    "enableVsync": "false",
    "particles": "1",
    "renderDistance": "10",
    "entityShadows": "false",
}


def update_options(game_dir: Path, enable_pack: bool, mute_music: bool, log=print) -> None:
    """Enable the pack (and optionally mute vanilla music) in options.txt before launch."""
    path = game_dir / "options.txt"
    fresh = not path.exists()
    lines = path.read_text(encoding="utf-8", errors="replace").splitlines() if not fresh else []
    kv = {}
    order = []
    for line in lines:
        if ":" in line:
            k, v = line.split(":", 1)
            kv[k] = v
            order.append(k)
    if fresh:
        for k, v in FRESH_OPTIONS.items():
            kv[k] = v
            order.append(k)

    if enable_pack:
        try:
            packs = json.loads(kv.get("resourcePacks", '["vanilla"]'))
        except ValueError:
            packs = ["vanilla"]
        entry = f"file/{PACK_NAME}"
        if entry not in packs:
            packs.append(entry)
        if "resourcePacks" not in kv:
            order.append("resourcePacks")
        kv["resourcePacks"] = json.dumps(packs, separators=(",", ":"))
    if mute_music:
        if "soundCategory_music" not in kv:
            order.append("soundCategory_music")
        kv["soundCategory_music"] = "0.0"

    path.write_text("\n".join(f"{k}:{kv[k]}" for k in order) + "\n", encoding="utf-8")
    if fresh:
        log("  created options.txt with performance defaults")
