"""In-game "now playing" pill: a small click-through window pinned to the top centre of the
Minecraft window (like the status pill in the video), showing the clock and the current song.

It is a separate always-on-top window drawn by the launcher, so it needs no Minecraft mod.
Works with windowed and borderless/fullscreen Minecraft. It never takes focus or mouse clicks.
"""
from __future__ import annotations

import os
import time
import tkinter as tk
from tkinter import font as tkfont

KEY = "#010203"            # colour treated as fully transparent on Windows
PILL_FILL = "#2b2040"
PILL_EDGE = "#8d76b4"
TEXT = "#ffffff"
CLOCK = "#ffe6d0"
ACCENT = "#ff8a45"
H = 34


def _win_rect_for_pid(pid: int):
    """Screen rectangle of the visible top-level window owned by pid (Windows only)."""
    import ctypes
    from ctypes import wintypes
    user32 = ctypes.windll.user32
    found = []

    @ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
    def cb(hwnd, _):
        if not user32.IsWindowVisible(hwnd):
            return True
        owner = wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(owner))
        if owner.value == pid:
            r = wintypes.RECT()
            user32.GetWindowRect(hwnd, ctypes.byref(r))
            if r.right - r.left > 300 and r.bottom - r.top > 200:
                found.append((r.left, r.top, r.right, r.bottom))
                return False
        return True

    user32.EnumWindows(cb, 0)
    return found[0] if found else None


def _foreground_pid() -> int | None:
    import ctypes
    from ctypes import wintypes
    user32 = ctypes.windll.user32
    hwnd = user32.GetForegroundWindow()
    if not hwnd:
        return None
    pid = wintypes.DWORD()
    user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    return pid.value


class NowPlayingOverlay:
    def __init__(self, root: tk.Misc, font_family: str = "Roboto"):
        self.root = root
        self.family = font_family
        self.win: tk.Toplevel | None = None
        self.pid: int | None = None
        self.attached = False
        self.title = ""
        self.paused = False
        self._job = None
        self._sig = None

    # ------------------------------------------------------------- public API
    def attach(self, pid: int | None = None) -> None:
        """Start following the game window (pid) - or the screen when pid is None."""
        self.pid = pid
        self.attached = True
        if self.win is None:
            self._build()
        self._tick()

    def detach(self) -> None:
        self.attached = False
        if self._job:
            try:
                self.root.after_cancel(self._job)
            except Exception:
                pass
            self._job = None
        if self.win is not None:
            try:
                self.win.destroy()
            except Exception:
                pass
            self.win = None
        self._sig = None

    def set_track(self, title: str, paused: bool = False) -> None:
        self.title, self.paused = title, paused
        if self.attached:
            self._redraw()

    # ------------------------------------------------------------- window
    def _build(self) -> None:
        w = tk.Toplevel(self.root)
        w.withdraw()
        w.overrideredirect(True)
        try:
            w.attributes("-topmost", True)
        except tk.TclError:
            pass
        self.shaped = os.name == "nt"
        w.configure(bg=KEY if self.shaped else PILL_FILL)
        if self.shaped:
            try:
                w.attributes("-transparentcolor", KEY)
            except tk.TclError:
                self.shaped = False
                w.configure(bg=PILL_FILL)
        else:
            try:
                w.attributes("-alpha", 0.92)
            except tk.TclError:
                pass
        self.cv = tk.Canvas(w, height=H, highlightthickness=0, bd=0, bg=w["bg"])
        self.cv.pack()
        self.f_title = tkfont.Font(family=self.family, size=-15, weight="bold")
        self.f_clock = tkfont.Font(family=self.family, size=-15)
        self.win = w
        self._styled = False

    def _click_through(self) -> None:
        if os.name != "nt" or self._styled or self.win is None:
            return
        try:
            import ctypes
            user32 = ctypes.windll.user32
            hwnd = user32.GetParent(self.win.winfo_id()) or self.win.winfo_id()
            style = user32.GetWindowLongW(hwnd, -20)
            # layered | transparent (click-through) | no-activate | tool window (no taskbar button)
            user32.SetWindowLongW(hwnd, -20, style | 0x80000 | 0x20 | 0x08000000 | 0x80)
            self._styled = True
        except Exception:
            pass

    def _pill(self, x0, y0, x1, y1, fill):
        r = (y1 - y0) / 2
        self.cv.create_oval(x0, y0, x0 + 2 * r, y1, fill=fill, outline="")
        self.cv.create_oval(x1 - 2 * r, y0, x1, y1, fill=fill, outline="")
        self.cv.create_rectangle(x0 + r, y0, x1 - r, y1, fill=fill, outline="")

    def _redraw(self) -> None:
        if self.win is None:
            return
        cv = self.cv
        cv.delete("all")
        clock = time.strftime("%H:%M")
        title = self.title if len(self.title) <= 34 else self.title[:33] + "…"
        label = ("Paused  ·  " if self.paused else "") + title
        cw, tw = self.f_clock.measure(clock), self.f_title.measure(label)
        pill_w = 14 + 16 + 10 + tw + 18
        total = cw + 12 + pill_w + 2
        cv.configure(width=total, height=H)
        y0, y1 = 1, H - 1
        x0 = cw + 12
        cv.create_text(0, H / 2, text=clock, anchor="w", font=self.f_clock, fill=CLOCK)
        if self.shaped:
            self._pill(x0 - 1, y0 - 1, x0 + pill_w + 1, y1 + 1, PILL_EDGE)
            self._pill(x0, y0, x0 + pill_w, y1, PILL_FILL)
        else:
            cv.create_rectangle(x0, y0, x0 + pill_w, y1, fill=PILL_FILL, outline=PILL_EDGE)
        # icon: pause bars or music note
        ix, iy = x0 + 16, H / 2
        if self.paused:
            cv.create_rectangle(ix - 5, iy - 6, ix - 1, iy + 6, fill=ACCENT, outline="")
            cv.create_rectangle(ix + 2, iy - 6, ix + 6, iy + 6, fill=ACCENT, outline="")
        else:
            cv.create_oval(ix - 6, iy + 1, ix + 2, iy + 8, fill=ACCENT, outline="")
            cv.create_line(ix + 1, iy + 4, ix + 1, iy - 7, fill=ACCENT, width=2)
            cv.create_polygon(ix + 1, iy - 7, ix + 8, iy - 4, ix + 8, iy - 1, ix + 1, iy - 4, fill=ACCENT, outline="")
        cv.create_text(x0 + 32, H / 2, text=label, anchor="w", font=self.f_title, fill=TEXT)
        self.win.update_idletasks()

    # ------------------------------------------------------------- follow loop
    def _tick(self) -> None:
        if not self.attached or self.win is None:
            return
        try:
            self._place()
        except Exception:
            pass
        self._job = self.root.after(700, self._tick)

    def _place(self) -> None:
        w = self.win
        visible = bool(self.title)
        rect = None
        if os.name == "nt" and self.pid:
            rect = _win_rect_for_pid(self.pid)
            if rect is None or _foreground_pid() != self.pid:
                visible = False                   # game closed/minimised/not focused
        if visible:
            sig = (self.title, self.paused, time.strftime("%H:%M"))
            if sig != self._sig:
                self._sig = sig
                self._redraw()
            self.win.update_idletasks()
            width = self.cv.winfo_reqwidth()
            if rect is None:
                sw, sh = w.winfo_screenwidth(), w.winfo_screenheight()
                left, top, right, bottom = 0, 0, sw, sh
            else:
                left, top, right, bottom = rect
                sw, sh = w.winfo_screenwidth(), w.winfo_screenheight()
            fullscreen = (right - left) >= sw - 4 and (bottom - top) >= sh - 4
            x = left + ((right - left) - width) // 2
            y = top + (10 if fullscreen else 46)
            w.geometry(f"+{x}+{y}")
            if w.state() == "withdrawn":
                w.deiconify()
                w.attributes("-topmost", True)
            w.lift()
            self._click_through()
        elif w.state() != "withdrawn":
            w.withdraw()
