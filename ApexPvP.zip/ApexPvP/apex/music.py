"""Background music player: plays every song in a folder (mp3 / ogg / wav / flac)."""
from __future__ import annotations

import os
import random
import threading
import time
from pathlib import Path

EXTENSIONS = {".mp3", ".ogg", ".wav", ".flac"}
UNSUPPORTED_HINT = {".m4a", ".aac", ".wma", ".opus"}


class MusicPlayer:
    def __init__(self, folder: Path, volume: float = 0.5, shuffle: bool = True):
        self.folder = Path(folder)
        self.volume = volume
        self.shuffle = shuffle
        self.tracks: list[Path] = []
        self.skipped: list[Path] = []
        self.index = -1
        self.playing = False
        self.paused = False
        self.error: str | None = None
        self.on_change = lambda: None
        self._lock = threading.RLock()
        self._mixer = None
        self._stop = threading.Event()
        self._hotkeys = None
        self._thread = threading.Thread(target=self._watch, daemon=True)
        self._thread.start()

    # ---------------------------------------------------------------- setup
    def _init_mixer(self) -> bool:
        if self._mixer is not None:
            return True
        try:
            os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")
            import pygame
            pygame.mixer.init()
            self._mixer = pygame.mixer
            self._mixer.music.set_volume(self.volume)
            self.error = None
            return True
        except Exception as e:  # no audio device, missing pygame, ...
            self.error = f"Audio unavailable: {e}"
            return False

    def scan(self, folder: Path | None = None) -> list[Path]:
        with self._lock:
            if folder is not None:
                self.folder = Path(folder)
            self.folder.mkdir(parents=True, exist_ok=True)
            files = sorted(p for p in self.folder.iterdir() if p.is_file())
            self.tracks = [p for p in files if p.suffix.lower() in EXTENSIONS]
            self.skipped = [p for p in files if p.suffix.lower() in UNSUPPORTED_HINT]
            if self.shuffle:
                random.shuffle(self.tracks)
            self.index = -1
            return self.tracks

    # ---------------------------------------------------------------- control
    @property
    def current(self) -> Path | None:
        with self._lock:
            if 0 <= self.index < len(self.tracks):
                return self.tracks[self.index]
            return None

    def _play_index(self, i: int) -> None:
        if not self.tracks or not self._init_mixer():
            self.playing = False
            self.on_change()
            return
        # skip files that fail to decode, but never loop forever
        for _ in range(len(self.tracks)):
            self.index = i % len(self.tracks)
            try:
                self._mixer.music.load(str(self.tracks[self.index]))
                self._mixer.music.set_volume(self.volume)
                self._mixer.music.play()
                self.playing, self.paused = True, False
                self.error = None
                self.on_change()
                return
            except Exception as e:
                self.error = f"Can't play {self.tracks[self.index].name}: {e}"
                i = self.index + 1
        self.playing = False
        self.on_change()

    def play(self) -> None:
        with self._lock:
            if not self.tracks:
                self.scan()
            if self.paused and self._mixer:
                self._mixer.music.unpause()
                self.paused, self.playing = False, True
                self.on_change()
            elif not self.playing:
                self._play_index(max(self.index, 0))

    def pause(self) -> None:
        with self._lock:
            if self.playing and self._mixer:
                self._mixer.music.pause()
                self.paused, self.playing = True, False
                self.on_change()

    def toggle(self) -> None:
        with self._lock:
            (self.pause if self.playing else self.play)()

    def next(self) -> None:
        with self._lock:
            if self.tracks:
                self._play_index(self.index + 1)

    def prev(self) -> None:
        with self._lock:
            if self.tracks:
                self._play_index(self.index - 1)

    def play_track(self, i: int) -> None:
        with self._lock:
            self._play_index(i)

    def stop(self) -> None:
        with self._lock:
            if self._mixer:
                self._mixer.music.stop()
            self.playing = self.paused = False
            self.on_change()

    def set_volume(self, v: float) -> None:
        self.volume = max(0.0, min(1.0, v))
        if self._mixer:
            self._mixer.music.set_volume(self.volume)

    def _watch(self) -> None:
        while not self._stop.wait(0.5):
            with self._lock:
                if self.playing and not self.paused and self._mixer and not self._mixer.music.get_busy():
                    self._play_index(self.index + 1)

    # ---------------------------------------------------------------- hotkeys
    def enable_hotkeys(self) -> bool:
        """Global keys that work while Minecraft has focus:
        Ctrl+Alt+Right = next, Ctrl+Alt+Left = previous, Ctrl+Alt+Space = play/pause."""
        self.disable_hotkeys()
        try:
            from pynput import keyboard
            self._hotkeys = keyboard.GlobalHotKeys({
                "<ctrl>+<alt>+<right>": self.next,
                "<ctrl>+<alt>+<left>": self.prev,
                "<ctrl>+<alt>+<space>": self.toggle,
            })
            self._hotkeys.start()
            return True
        except Exception:
            self._hotkeys = None
            return False

    def disable_hotkeys(self) -> None:
        if self._hotkeys:
            try:
                self._hotkeys.stop()
            except Exception:
                pass
            self._hotkeys = None

    def shutdown(self) -> None:
        self._stop.set()
        self.disable_hotkeys()
        self.stop()
        if self._mixer:
            try:
                self._mixer.quit()
            except Exception:
                pass
