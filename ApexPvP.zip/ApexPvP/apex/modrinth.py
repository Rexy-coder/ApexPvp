"""Tiny Modrinth client: find the newest Fabric build of a mod for a Minecraft version,
resolve required dependencies, download + verify files."""
import hashlib
import json
import re
from pathlib import Path

import requests

API = "https://api.modrinth.com/v2"
HEADERS = {"User-Agent": "ApexPvP-Launcher/1.0 (standalone PvP client)"}
# Never auto-pick anything that looks like a cheat/unfair-advantage mod.
BLOCKLIST = re.compile(
    r"hack|cheat|x-?ray|kill\s?aura|aim\s?bot|auto\s?-?click|hitbox|reach|velocity|bypass|freecam",
    re.I,
)


class ModrinthError(Exception):
    pass


def _get(path: str, params: dict | None = None):
    r = requests.get(API + path, params=params, headers=HEADERS, timeout=30)
    if r.status_code == 404:
        return None
    r.raise_for_status()
    return r.json()


def _pick(versions: list[dict]) -> dict | None:
    if not versions:
        return None
    releases = [v for v in versions if v.get("version_type") == "release"]
    pool = releases or versions
    return sorted(pool, key=lambda v: v["date_published"], reverse=True)[0]


def latest_version(project: str, mc_version: str) -> dict | None:
    """project = slug or id. Returns the newest compatible Fabric version dict or None."""
    versions = _get(
        f"/project/{project}/version",
        {"loaders": json.dumps(["fabric"]), "game_versions": json.dumps([mc_version])},
    )
    return _pick(versions or [])


def search(query: str, mc_version: str, min_downloads: int = 2000) -> list[dict]:
    facets = [["project_type:mod"], ["categories:fabric"], [f"versions:{mc_version}"]]
    data = _get(
        "/search",
        {"query": query, "facets": json.dumps(facets), "index": "downloads", "limit": 15},
    )
    out = []
    for hit in (data or {}).get("hits", []):
        if hit.get("client_side") == "unsupported":
            continue
        if hit.get("downloads", 0) < min_downloads:
            continue
        text = f"{hit.get('title', '')} {hit.get('description', '')} {hit.get('slug', '')}"
        if BLOCKLIST.search(text):
            continue
        out.append(hit)
    return out


def primary_file(version: dict) -> dict:
    files = version["files"]
    return next((f for f in files if f.get("primary")), files[0])


def resolve_slot(slot: dict, mc_version: str, log=print) -> tuple[dict, dict] | None:
    """Return (project_ref, version) for a mod slot, or None if nothing compatible exists."""
    for slug in slot.get("slugs", []):
        try:
            v = latest_version(slug, mc_version)
        except requests.RequestException as e:
            raise ModrinthError(f"Modrinth request failed: {e}") from e
        if v:
            return {"slug": slug, "project_id": v["project_id"]}, v
    query = slot.get("search")
    if query:
        try:
            hits = search(query, mc_version)
        except requests.RequestException as e:
            raise ModrinthError(f"Modrinth search failed: {e}") from e
        for hit in hits:
            v = latest_version(hit["project_id"], mc_version)
            if v:
                log(f"  {slot['name']}: picked '{hit['title']}' ({hit['downloads']:,} downloads)")
                return {"slug": hit["slug"], "project_id": hit["project_id"]}, v
    return None


def required_dependencies(version: dict, mc_version: str) -> list[tuple[dict, dict]]:
    out = []
    for dep in version.get("dependencies", []):
        if dep.get("dependency_type") != "required" or not dep.get("project_id"):
            continue
        v = latest_version(dep["project_id"], mc_version)
        if v:
            out.append(({"slug": dep["project_id"], "project_id": dep["project_id"]}, v))
    return out


def download(file: dict, dest: Path) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    expected = file.get("hashes", {}).get("sha512")
    if dest.exists() and expected and _sha512(dest) == expected:
        return
    tmp = dest.with_suffix(dest.suffix + ".part")
    sha = hashlib.sha512()
    with requests.get(file["url"], headers=HEADERS, stream=True, timeout=60) as r:
        r.raise_for_status()
        with open(tmp, "wb") as fh:
            for chunk in r.iter_content(1 << 16):
                fh.write(chunk)
                sha.update(chunk)
    if expected and sha.hexdigest() != expected:
        tmp.unlink(missing_ok=True)
        raise ModrinthError(f"Checksum mismatch for {file['filename']}")
    tmp.replace(dest)


def _sha512(path: Path) -> str:
    h = hashlib.sha512()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 16), b""):
            h.update(chunk)
    return h.hexdigest()
