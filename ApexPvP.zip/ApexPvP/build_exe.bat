@echo off
rem Optional: builds a double-clickable ApexPvP.exe (Windows). Run run.bat once first.
setlocal
cd /d "%~dp0"
call "venv\Scripts\activate.bat"
pip install --quiet pyinstaller
pyinstaller --noconfirm --noconsole --onedir --name ApexPvP --collect-all customtkinter --collect-all minecraft_launcher_lib --collect-all pygame main.py
if not exist "dist\ApexPvP\music" mkdir "dist\ApexPvP\music"
echo.
echo Done. Your client is in dist\ApexPvP\ApexPvP.exe  (put songs in dist\ApexPvP\music)
pause
