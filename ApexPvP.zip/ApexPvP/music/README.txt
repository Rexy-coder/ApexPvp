Put your songs in this folder (mp3, ogg, wav or flac) and press Play in ApexPvP.
They start with the game and keep looping through the playlist.
In game:  Ctrl+Alt+Right = next song   Ctrl+Alt+Left = previous   Ctrl+Alt+Space = pause/resume
You can also pick any other folder on the Music tab.
