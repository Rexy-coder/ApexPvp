#!/usr/bin/env bash
# Linux / macOS launcher (needs Python 3.10+ with tkinter: e.g. `sudo apt install python3-tk`)
cd "$(dirname "$0")"
[ -d venv ] || python3 -m venv venv || exit 1
if [ ! -f venv/.deps_ok ]; then
  venv/bin/pip install -q -r requirements.txt || exit 1
  venv/bin/pip install -q -r requirements-optional.txt || echo "Music extras not installed - client still works."
  touch venv/.deps_ok
fi
exec venv/bin/python main.py
