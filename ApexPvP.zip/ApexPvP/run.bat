@echo off
setlocal
cd /d "%~dp0"
set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY where python >nul 2>nul && set "PY=python"
if not defined PY (
  echo Python was not found. Trying to install it automatically...
  where winget >nul 2>nul && winget install -e --id Python.Python.3.12 --silent --accept-package-agreements --accept-source-agreements
  where winget >nul 2>nul && (
    echo.
    echo If the install finished, close this window and double-click run.bat again.
    pause
    exit /b 0
  )
  echo Opening the Python download page - tick "Add python.exe to PATH" when installing, then run this file again.
  start "" https://www.python.org/downloads/
  pause
  exit /b 1
)
if not exist "venv\Scripts\python.exe" %PY% -m venv venv
if not exist "venv\.deps_ok" (
  echo Installing ApexPvP dependencies ^(first run only^)...
  "venv\Scripts\python.exe" -m pip install --quiet --upgrade pip
  "venv\Scripts\python.exe" -m pip install --quiet -r requirements.txt || (echo Dependency install failed. & pause & exit /b 1)
  "venv\Scripts\python.exe" -m pip install --quiet -r requirements-optional.txt || echo Music extras could not be installed - the client still works.
  echo ok> "venv\.deps_ok"
)
start "" "venv\Scripts\pythonw.exe" main.py
